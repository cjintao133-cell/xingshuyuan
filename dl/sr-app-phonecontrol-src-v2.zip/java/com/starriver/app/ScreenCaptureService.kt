package com.starriver.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import java.io.ByteArrayOutputStream

/** 屏幕捕获前台服务：持有 MediaProjection，按需抓一帧 JPEG，供视觉模型“看”手机画面。 */
class ScreenCaptureService : Service() {
    companion object {
        const val CH = "sr_screen"; const val NID = 2002
        @Volatile var instance: ScreenCaptureService? = null
        fun start(ctx: Context, code: Int, data: Intent) {
            val i = Intent(ctx, ScreenCaptureService::class.java)
            i.putExtra("code", code); i.putExtra("data", data)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
        fun grab(): ByteArray? = instance?.capture()
        fun isReady(): Boolean = instance?.reader != null
    }
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private var w = 720; private var h = 1280; private var dpi = 320

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate(); instance = this
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) nm.createNotificationChannel(NotificationChannel(CH, "屏幕读取", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, CH).setContentTitle("Star River · 屏幕读取运行中").setContentText("AI 可读取屏幕以协助操作手机")
            .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(NID, n)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("data", Intent::class.java)
            else @Suppress("DEPRECATION") intent?.getParcelableExtra("data")
        if (data != null && projection == null) setup(code, data)
        return START_NOT_STICKY
    }
    private fun setup(code: Int, data: Intent) {
        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            projection = mpm.getMediaProjection(code, data)
            val dm = resources.displayMetrics
            val scale = 720f / dm.widthPixels.toFloat()
            w = 720; h = (dm.heightPixels * scale).toInt(); dpi = dm.densityDpi
            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
            vdisplay = projection?.createVirtualDisplay("srcap", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        } catch (e: Exception) { }
    }
    fun capture(): ByteArray? {
        val r = reader ?: return null
        var image: Image? = null
        val deadline = System.currentTimeMillis() + 1800
        while (image == null && System.currentTimeMillis() < deadline) {
            image = try { r.acquireLatestImage() } catch (e: Exception) { null }
            if (image == null) { try { Thread.sleep(70) } catch (e: InterruptedException) {} }
        }
        val img = image ?: return null
        return try {
            val plane = img.planes[0]; val rowStride = plane.rowStride; val pixelStride = plane.pixelStride
            val rowPadding = rowStride - pixelStride * w
            val bmp = Bitmap.createBitmap(w + rowPadding / pixelStride, h, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(plane.buffer)
            val cropped = Bitmap.createBitmap(bmp, 0, 0, w, h)
            val baos = ByteArrayOutputStream(); cropped.compress(Bitmap.CompressFormat.JPEG, 55, baos)
            cropped.recycle(); bmp.recycle(); baos.toByteArray()
        } catch (e: Exception) { null } finally { try { img.close() } catch (e: Exception) {} }
    }
    override fun onDestroy() {
        try { vdisplay?.release() } catch (e: Exception) {}
        try { reader?.close() } catch (e: Exception) {}
        try { projection?.stop() } catch (e: Exception) {}
        if (instance === this) instance = null
        super.onDestroy()
    }
}
