package com.starriver.app

import android.content.Context
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import mobilebind.Mobilebind
import java.security.SecureRandom

/**
 * 内核自启：生成/复用一个 32 字节字段加密钥（经 SecretStore/Keystore 加密持有），
 * 打开本地 SQLite 内核（mobilebind.initKernel），并初始化 MCP 热插拔层（mcpInit + 后台 mcpRestore）。幂等。
 */
object KernelBoot {
    private const val KEY_ID = "kernel.field_key"

    @Volatile
    private var inited = false

    /** 内核是否就绪（Compose 可观察）：后台初始化完成后置 true，界面据此刷新数据。 */
    var ready by mutableStateOf(false)
        private set

    fun ensure(ctx: Context): String {
        if (inited) return "OK"
        val b64 = SecretStore.get(ctx, KEY_ID) ?: run {
            val key = ByteArray(32)
            SecureRandom().nextBytes(key)
            val s = Base64.encodeToString(key, Base64.NO_WRAP)
            SecretStore.put(ctx, KEY_ID, s)
            s
        }
        val r = try {
            Mobilebind.initKernel(ctx.filesDir.absolutePath + "/star-river.db", b64)
        } catch (t: Throwable) {
            "ERR:" + (t.message ?: "init failed")
        }
        if (r == "OK") {
            inited = true
            ready = true
            // MCP 热插拔层：加载已装插件配置；后台重连"启用"的插件（不阻塞启动）。
            try { Mobilebind.mcpInit(ctx.filesDir.absolutePath + "/mcp_servers.json") } catch (t: Throwable) { }
            // 本地 MCP server(127.0.0.1)：注册手机控制工具，带进程内随机 Token 接入内核
            try {
                AppAudit.init(ctx)
                PhoneControl.registerAll(ctx)
                val tok = LocalMcpServer.ensureStarted()
                // 先移除上次可能残留的 localtest（清旧 token、避免 already exists），再带本次 token 注册
                runCatching { Mobilebind.mcpRemoveServer("localtest") }
                val r = Mobilebind.mcpAddServer("localtest", LocalMcpServer.endpoint, "{\"Authorization\":\"Bearer " + tok + "\"}")
                AppAudit.log("MCP localtest 注册: " + r)
            } catch (t: Throwable) { android.util.Log.e("KernelBoot", "local mcp: " + (t.message ?: "")) }
            try { HeaderHelp.apply(ctx) } catch (t: Throwable) { }
            Thread { try { Mobilebind.mcpRestore() } catch (t: Throwable) { } }.start()
        }
        return r
    }

    /** 自愈/看门狗用：重新打开内核（幂等）。不改密钥、不覆盖损坏数据。 */
    fun reinit(ctx: Context): String {
        inited = false
        ready = false
        return ensure(ctx)
    }

    fun isInited(): Boolean = inited
}
