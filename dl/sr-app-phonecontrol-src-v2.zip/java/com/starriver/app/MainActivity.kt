package com.starriver.app

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color as C
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Density
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * 星海容器 · Android 入口（完整四栏：消息 / 联系人 / 社区 / 设置）。
 * 界面来自完整 UI 组；内核经 KernelBoot 启动，Jinvia 沙箱经 JinviaBridge 自检。
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
        )
        AppCtx.ctx = applicationContext
        Notify.ensureChannel(applicationContext)
        Notify.requestPermission(this)
        SharedInbox.handleIntent(applicationContext, intent)
        Diag.install(this)
        val initial = ConfigStore.load(this)
        AppI18n.load(this, LangPrefs.lang(this))
        // 立即渲染 UI（不阻塞主线程）。内核初始化移入后台线程，就绪后置 KernelBoot.ready 触发数据刷新。
        setContent { RootScaffold(initial) }
        KeepAliveService.start(applicationContext)
        Thread {
            val r = KernelBoot.ensure(applicationContext)
            try { val jp = JinviaBridge.probe(applicationContext); Log.i("Jinvia", "sandbox probe: $jp") }
            catch (t: Throwable) { Log.e("Jinvia", "probe err: ${t.message}") }
            if (r == "OK") {
                try { ProtoPrefs.apply(applicationContext) } catch (t: Throwable) { }
                try { EmbedPrefs.apply(applicationContext) } catch (t: Throwable) { }
                try { BackupPrefs.apply(applicationContext) } catch (t: Throwable) { }
                try { ProxyPrefs.apply(applicationContext) } catch (t: Throwable) { }
            }
        }.start()
    }
    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        SharedInbox.handleIntent(applicationContext, intent)
    }
    override fun onResume() { super.onResume(); Notify.foreground = true }
    override fun onPause() { super.onPause(); Notify.foreground = false }
}

@Composable
private fun RootScaffold(initial: ChatConfig) {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    val app = remember { AppState() }
    var config by remember { mutableStateOf(initial) }
    var theme by remember { mutableStateOf(ThemePrefs.load(ctx)) }
    var reduceMotion by remember { mutableStateOf(UiPrefs.reduceMotion(ctx)) }
    var lang by remember { mutableStateOf(LangPrefs.lang(ctx)) }
    var followSystem by remember { mutableStateOf(SysPrefs.followSystem(ctx)) }
    var fontScale by remember { mutableStateOf(UiPrefs.fontScale(ctx)) }
    val baseDensity = LocalDensity.current
    var onboarded by remember { mutableStateOf(Onboarding.isDone(ctx)) }

    LaunchedEffect(lang, followSystem) {
        AppI18n.load(ctx, if (followSystem) AppI18n.systemLang() else lang)
    }

    val screenBody: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> MessageTab(config, app, onOpenSettings = { tab = 3 })
                1 -> ContactsTab(config, app, onOpenMessages = { tab = 0 })
                2 -> CommunityTab()
                else -> SettingsTab(
                    config = config,
                    theme = theme,
                    reduceMotion = reduceMotion,
                    lang = lang,
                    followSystem = followSystem,
                    onThemeChange = { theme = it; ThemePrefs.save(ctx, it) },
                    onReduceMotionChange = { reduceMotion = it; UiPrefs.setReduceMotion(ctx, it) },
                    onLangChange = { lang = it; LangPrefs.setLang(ctx, it); if (followSystem) { followSystem = false; SysPrefs.setFollowSystem(ctx, false) } },
                    onFollowSystem = {
                        followSystem = !followSystem
                        SysPrefs.setFollowSystem(ctx, followSystem)
                    },
                    onSave = { config = it; ConfigStore.save(ctx, it) },
                    fontScale = fontScale,
                    onFontScaleChange = { fontScale = it; UiPrefs.setFontScale(ctx, it) },
                )
            }
        }
        BottomBar(tab) { tab = it }
    }

    CompositionLocalProvider(LocalDensity provides Density(baseDensity.density, baseDensity.fontScale * fontScale)) {
    AppTheme(theme) {
      androidx.compose.foundation.layout.Box(androidx.compose.ui.Modifier.fillMaxSize()) {
        if (!onboarded) {
            OnboardingScreen(
                onFinish = { Onboarding.markDone(ctx); onboarded = true; tab = 0 },
                onNavigate = { t -> Onboarding.markDone(ctx); onboarded = true; tab = t },
            )
        } else if (theme.mode == ThemeMode.NIGHT) {
            // 夜间流星氛围背景（reduceMotion / 低端机 自动降级为静态星空）
            StarryBackdrop(reduceMotion) {
                Column(Modifier.fillMaxSize().systemBarsPadding()) { screenBody() }
            }
        } else {
            Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding()) { screenBody() }
        }
        ApprovalDialog()
      }
    }
    }
}

@Composable
private fun BottomBar(cur: Int, onSel: (Int) -> Unit) {
    val items = listOf(tr("nav.messages", "消息"), tr("nav.contacts", "联系人"), tr("nav.community", "社区"), tr("nav.settings", "设置"))
    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)))
        Row(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            items.forEachIndexed { i, label ->
                val on = cur == i
                val tint = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { onSel(i) }.padding(horizontal = 8.dp, vertical = 2.dp),
                ) {
                    when (i) {
                        0 -> IconChat(tint, 22.dp)
                        1 -> IconContacts(tint, 22.dp)
                        2 -> IconCommunity(tint, 22.dp)
                        else -> IconSettings(tint, 22.dp)
                    }
                    Text(
                        label,
                        fontSize = 12.sp,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                        color = tint,
                    )
                }
            }
        }
    }
}
