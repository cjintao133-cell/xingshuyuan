package com.starriver.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo

/** 手机控制逻辑：读屏、按文字/坐标点击、滑动、输入、全局按键。依赖 PhoneAccessibilityService。 */
object DeviceCtrl {
    private fun svc(): PhoneAccessibilityService? = PhoneAccessibilityService.instance
    private fun root(): AccessibilityNodeInfo? = try { svc()?.rootInActiveWindow } catch (e: Exception) { null }
    private fun center(n: AccessibilityNodeInfo): Pair<Int, Int> { val r = Rect(); n.getBoundsInScreen(r); return r.centerX() to r.centerY() }

    fun ready(): Boolean = svc() != null

    fun dump(): String {
        val rt = root() ?: return "无障碍服务未开启（系统设置→无障碍→已安装的服务→打开「星枢元·手机控制」）"
        val sb = StringBuilder(); var idx = 0
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || idx >= 120) return
            val t = n.text?.toString()?.trim().orEmpty(); val d = n.contentDescription?.toString()?.trim().orEmpty()
            val label = if (t.isNotEmpty()) t else d
            if (n.isVisibleToUser && label.isNotEmpty()) {
                val c = center(n)
                sb.append("#").append(idx).append(" ").append(label)
                if (n.isClickable) sb.append(" [可点]")
                sb.append(" @(").append(c.first).append(",").append(c.second).append(")\n"); idx++
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rt)
        return if (sb.isEmpty()) "当前界面没读到可识别文字（可能是游戏/自绘界面，可用坐标点击 phone_tap）" else "当前界面元素：\n" + sb.toString()
    }

    private fun findByText(contains: String): AccessibilityNodeInfo? {
        val rt = root() ?: return null; var found: AccessibilityNodeInfo? = null
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || found != null) return
            val t = n.text?.toString().orEmpty(); val d = n.contentDescription?.toString().orEmpty()
            if (t.contains(contains) || d.contains(contains)) { found = n; return }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rt); return found
    }

    fun tapText(contains: String): String {
        val n = findByText(contains) ?: return "没找到包含「$contains」的元素"
        val clickable = if (n.isClickable) n else (n.parent ?: n)
        if (clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "已点击「$contains」"
        val c = center(n); return tap(c.first, c.second)
    }

    fun tap(x: Int, y: Int): String {
        val s = svc() ?: return "无障碍服务未开启"
        val p = Path(); p.moveTo(x.toFloat(), y.toFloat())
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 80)).build()
        return if (s.dispatchGesture(g, null, null)) "已点击坐标 ($x,$y)" else "点击失败"
    }

    fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, ms: Long): String {
        val s = svc() ?: return "无障碍服务未开启"
        val p = Path(); p.moveTo(x1.toFloat(), y1.toFloat()); p.lineTo(x2.toFloat(), y2.toFloat())
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms.coerceIn(50, 2000))).build()
        return if (s.dispatchGesture(g, null, null)) "已从 ($x1,$y1) 滑到 ($x2,$y2)" else "滑动失败"
    }

    fun typeText(text: String): String {
        val rt = root() ?: return "无障碍服务未开启"
        val focus = rt.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "当前没有聚焦的输入框（先点一下输入框再调用）"
        val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return if (focus.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "已输入：$text" else "输入失败"
    }

    fun global(action: String): String {
        val s = svc() ?: return "无障碍服务未开启"
        val code = when (action.lowercase()) {
            "back", "返回" -> AccessibilityService.GLOBAL_ACTION_BACK
            "home", "主页", "桌面" -> AccessibilityService.GLOBAL_ACTION_HOME
            "recents", "最近", "多任务" -> AccessibilityService.GLOBAL_ACTION_RECENTS
            "notifications", "通知", "下拉" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            else -> return "未知按键：$action"
        }
        return if (s.performGlobalAction(code)) "已执行：$action" else "执行失败"
    }
}
