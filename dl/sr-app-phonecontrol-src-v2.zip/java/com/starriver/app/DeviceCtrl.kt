package com.starriver.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo

/** 手机控制逻辑（含遍历/坐标安全边界）。依赖 PhoneAccessibilityService。 */
object DeviceCtrl {
    private const val MAX_NODES = 1000
    private const val MAX_DEPTH = 40
    private const val MAX_ANCESTOR = 20

    private fun svc(): PhoneAccessibilityService? = PhoneAccessibilityService.instance
    private fun root(): AccessibilityNodeInfo? = try { svc()?.rootInActiveWindow } catch (e: Exception) { null }

    private fun center(n: AccessibilityNodeInfo): Pair<Int, Int> { val r = Rect(); n.getBoundsInScreen(r); return r.centerX() to r.centerY() }

    /** 屏幕尺寸（像素）。取不到返回 null（视为不校验）。 */
    private fun screenSize(): Pair<Int, Int>? = try {
        val dm = svc()?.resources?.displayMetrics
        if (dm == null || dm.widthPixels <= 0 || dm.heightPixels <= 0) null else (dm.widthPixels to dm.heightPixels)
    } catch (e: Exception) { null }

    /** 坐标范围。屏幕尺寸取不到时 fail-closed（返回 false），由调用方给出明确错误。 */
    private fun inBounds(x: Int, y: Int): Boolean {
        val wh = screenSize() ?: return false
        return x in 0 until wh.first && y in 0 until wh.second
    }

    fun ready(): Boolean = svc() != null

    fun dump(): String {
        val rt = root() ?: return "无障碍服务未开启（系统设置→无障碍→已安装的服务→打开「星枢元·手机控制」）"
        val sb = StringBuilder(); var idx = 0; var visited = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || visited >= MAX_NODES || depth > MAX_DEPTH) return
            visited++
            try {
                val t = n.text?.toString()?.trim().orEmpty(); val d = n.contentDescription?.toString()?.trim().orEmpty()
                val label = if (t.isNotEmpty()) t else d
                if (n.isVisibleToUser && label.isNotEmpty() && idx < 120) {
                    val c = center(n)
                    sb.append("#").append(idx).append(" ").append(label)
                    if (n.isClickable) sb.append(" [可点]")
                    sb.append(" @(").append(c.first).append(",").append(c.second).append(")\n"); idx++
                }
            } catch (e: Exception) { /* 跳过异常节点属性 */ }
            val cc = try { n.childCount } catch (e: Exception) { 0 }
            for (i in 0 until cc) walk(try { n.getChild(i) } catch (e: Exception) { null }, depth + 1)
        }
        walk(rt, 0)
        return if (sb.isEmpty()) "当前界面没读到可识别文字（可能是游戏/自绘界面，可用坐标点击 phone_tap）" else "当前界面元素：\n" + sb.toString()
    }

    /** 收集所有“可见且文字/描述包含 contains”的节点（有界遍历、跳过异常节点）。 */
    private fun visibleMatches(contains: String): List<AccessibilityNodeInfo> {
        val rt = root() ?: return emptyList()
        val out = ArrayList<AccessibilityNodeInfo>(); var visited = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || visited >= MAX_NODES || depth > MAX_DEPTH) return
            visited++
            try {
                if (n.isVisibleToUser) {
                    val t = n.text?.toString().orEmpty(); val d = n.contentDescription?.toString().orEmpty()
                    if (t.contains(contains) || d.contains(contains)) out.add(n)
                }
            } catch (e: Exception) { }
            val cc = try { n.childCount } catch (e: Exception) { 0 }
            for (i in 0 until cc) walk(try { n.getChild(i) } catch (e: Exception) { null }, depth + 1)
        }
        walk(rt, 0)
        return out
    }

    private fun clickableAncestor(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var cur: AccessibilityNodeInfo? = n; var d = 0
        while (cur != null && d < MAX_ANCESTOR) { if (cur.isClickable) return cur; cur = cur.parent; d++ }
        return null
    }

    fun tapText(contains: String): String {
        val targets = visibleMatches(contains)
        if (targets.isEmpty()) return "没找到包含「$contains」的可见元素"
        if (targets.size > 1) return "找到多个（${targets.size} 个）包含「$contains」的可见元素，为避免误点已取消；请用更精确的文字或改用 phone_tap 坐标"
        val n = targets[0]
        val anc = clickableAncestor(n) ?: n
        if (anc.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "已点击「$contains」"
        val c = center(n); return tap(c.first, c.second)
    }

    fun tap(x: Int, y: Int): String {
        val s = svc() ?: return "无障碍服务未开启"
        val wh = screenSize() ?: return "无法确认屏幕尺寸，操作已取消"
        if (x < 0 || y < 0 || x >= wh.first || y >= wh.second) return "坐标越界：($x,$y) 不在屏幕范围（${wh.first}x${wh.second}）"
        val p = Path(); p.moveTo(x.toFloat(), y.toFloat())
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 80)).build()
        return if (s.dispatchGesture(g, null, null)) "已点击坐标 ($x,$y)" else "点击失败"
    }

    fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, ms: Long): String {
        val s = svc() ?: return "无障碍服务未开启"
        val wh = screenSize() ?: return "无法确认屏幕尺寸，操作已取消"
        if (x1 < 0 || y1 < 0 || x1 >= wh.first || y1 >= wh.second || x2 < 0 || y2 < 0 || x2 >= wh.first || y2 >= wh.second)
            return "坐标越界：起点($x1,$y1)或终点($x2,$y2)不在屏幕范围（${wh.first}x${wh.second}）"
        val p = Path(); p.moveTo(x1.toFloat(), y1.toFloat()); p.lineTo(x2.toFloat(), y2.toFloat())
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms.coerceIn(50, 2000))).build()
        return if (s.dispatchGesture(g, null, null)) "已从 ($x1,$y1) 滑到 ($x2,$y2)" else "滑动失败"
    }

    /** 输入文字到当前聚焦输入框；不回传输入正文（只报字符数）。 */
    fun typeText(text: String): String {
        val rt = root() ?: return "无障碍服务未开启"
        val focus = rt.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "当前没有聚焦的输入框（先点一下输入框再调用）"
        val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return if (focus.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "已执行输入操作（字符数：${text.length}）" else "输入失败"
    }

    fun global(action: String): String {
        val s = svc() ?: return "无障碍服务未开启"
        val code = when (action.lowercase()) {
            "back","返回" -> AccessibilityService.GLOBAL_ACTION_BACK
            "home","主页","桌面" -> AccessibilityService.GLOBAL_ACTION_HOME
            "recents","最近","多任务" -> AccessibilityService.GLOBAL_ACTION_RECENTS
            "notifications","通知","下拉" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            else -> return "未知按键：$action"
        }
        return if (s.performGlobalAction(code)) "已执行：$action" else "执行失败"
    }
}
