package com.starriver.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/** 手机控制无障碍服务：持有全局实例，供 DeviceCtrl/工具调用读屏与模拟操作。 */
class PhoneAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }
    companion object {
        @Volatile var instance: PhoneAccessibilityService? = null
        fun isReady(): Boolean = instance != null
    }
}
