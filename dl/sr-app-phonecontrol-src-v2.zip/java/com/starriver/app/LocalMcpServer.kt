package com.starriver.app

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.Semaphore

/** MCP 工具结果内容块：type=text(text) 或 type=image(data base64 + mimeType)。 */
class McpContent(val type: String, val text: String? = null, val data: String? = null, val mimeType: String? = null) {
    fun toJson(): JSONObject {
        val o = JSONObject().put("type", type)
        if (text != null) o.put("text", text)
        if (data != null) { o.put("data", data); if (mimeType != null) o.put("mimeType", mimeType) }
        return o
    }
    companion object { fun text(s: String) = McpContent("text", text = s) }
}

interface McpTool {
    val name: String
    val description: String
    val isWrite: Boolean get() = false
    fun inputSchema(): JSONObject
    fun execute(args: JSONObject): List<McpContent>
}

/**
 * 极简本地 MCP server（无状态、纯 application/json）。
 * 只绑 127.0.0.1；所有请求先校验 Bearer token，否则 401。
 * 严格 HTTP 解析：头行/请求体超限、头不完整、请求体读不满、重复 Content-Length、带 Transfer-Encoding 一律拒绝。
 * 资源上限：并发连接、请求体、单条工具结果文本、截图原始大小、响应体总大小。
 * 写操作在 execute 前经 ApprovalGate 硬阻断审批；审计只记事件不记正文。
 */
object LocalMcpServer {
    private const val TAG = "LocalMcpServer"
    const val PORT = 18321
    private const val PROTO = "2025-06-18"
    val endpoint: String get() = "http://127.0.0.1:$PORT/mcp"

    private const val MAX_CONN = 8
    private const val MAX_BODY = 1048576           // 请求体 1 MiB
    private const val MAX_LINE = 8 * 1024          // 单行 8 KiB
    private const val MAX_HEADERS = 64
    private const val MAX_RESULT_TEXT = 131072     // 单条工具文本结果 128 KiB
    private const val MAX_IMAGE_BYTES = 2097152    // 截图原始 2 MiB
    private const val MAX_RESP_BODY = 4194304      // 响应体 4 MiB

    private val tools = LinkedHashMap<String, McpTool>()
    private val connPermits = Semaphore(MAX_CONN)
    @Volatile private var started = false
    private var server: ServerSocket? = null
    @Volatile private var token: String = ""

    fun register(t: McpTool) { synchronized(tools) { tools[t.name] = t } }
    fun toolCount(): Int = synchronized(tools) { tools.size }
    fun toolNames(): List<String> = synchronized(tools) { tools.keys.toList() }
    fun token(): String = token

    private fun newToken(): String {
        val b = ByteArray(24); SecureRandom().nextBytes(b)
        val sb = StringBuilder(); for (x in b) sb.append(String.format("%02x", x)); return sb.toString()
    }

    /** 启动（幂等）。成功返回 token；绑定失败返回空串且不置 started。 */
    fun ensureStarted(): String {
        if (started) return token
        synchronized(this) {
            if (started) return token
            val t = newToken()
            try {
                val ss = ServerSocket(PORT, 16, InetAddress.getByName("127.0.0.1"))
                server = ss; token = t; started = true
                Thread({
                    while (!ss.isClosed) {
                        val s = try { ss.accept() } catch (ex: Throwable) { if (ss.isClosed) break; continue }
                        if (!connPermits.tryAcquire()) { try { s.close() } catch (e: Exception) {} ; continue }
                        Thread { try { handle(s) } finally { connPermits.release() } }.start()
                    }
                }, "local-mcp-accept").apply { isDaemon = true }.start()
                Log.i(TAG, "local MCP server started at $endpoint")
                return token
            } catch (ex: Throwable) {
                Log.e(TAG, "start failed: " + (ex.message ?: "")); started = false; token = ""; return ""
            }
        }
    }

    /** 给用户看的完整参数（不截断；超长全文由弹窗滚动查看）。 */
    private fun describeArgs(args: JSONObject): String {
        if (args.length() == 0) return "（无参数）"
        val sb = StringBuilder(); val it = args.keys()
        while (it.hasNext()) {
            val k = it.next(); val v = args.opt(k)?.toString() ?: ""
            if (sb.isNotEmpty()) sb.append(", ")
            sb.append(k).append("=").append(v)
        }
        return sb.toString()
    }

    /** 行读取结果：status 0=正常行，1=EOF，2=超长。 */
    private class LineRes(val status: Int, val line: String?)
    private fun readLine(ins: InputStream, max: Int): LineRes {
        val sb = StringBuilder()
        while (true) {
            val b = ins.read()
            if (b == -1) return LineRes(1, if (sb.isEmpty()) null else sb.toString())
            if (b == '\n'.code) { val s = sb.toString(); return LineRes(0, if (s.endsWith("\r")) s.dropLast(1) else s) }
            sb.append(b.toChar())
            if (sb.length > max) return LineRes(2, null)
        }
    }

    private fun handle(sock: Socket) {
        try {
            sock.soTimeout = 15000
            val ins = sock.getInputStream(); val outs = sock.getOutputStream()
            val rl = readLine(ins, MAX_LINE)
            if (rl.status != 0) { writeResp(outs, 431, null); sock.close(); return }
            val method = rl.line!!.split(" ").getOrNull(0) ?: ""
            var contentLength = -1; var clSeen = false; var auth = ""; var transferEnc = false; var hcount = 0
            while (true) {
                val h = readLine(ins, MAX_LINE)
                if (h.status == 1) break                                  // 正常 EOF（头结束无空行）
                if (h.status == 2) { writeResp(outs, 431, null); sock.close(); return } // 超长头行 -> 拒绝
                val line = h.line!!
                if (line.isEmpty()) break
                hcount++; if (hcount > MAX_HEADERS) { writeResp(outs, 431, null); sock.close(); return }
                val idx = line.indexOf(':'); if (idx <= 0) continue
                val k = line.substring(0, idx).trim().lowercase(); val v = line.substring(idx + 1).trim()
                when (k) {
                    "content-length" -> { if (clSeen) { writeResp(outs, 400, null); sock.close(); return }; clSeen = true; contentLength = v.toIntOrNull() ?: -1 }
                    "authorization" -> auth = v
                    "transfer-encoding" -> transferEnc = true
                }
            }
            if (transferEnc) { writeResp(outs, 400, null); sock.close(); return }   // 不支持 chunked
            if (clSeen && contentLength < 0) { writeResp(outs, 400, null); sock.close(); return }
            if (contentLength > MAX_BODY) { writeResp(outs, 413, null); sock.close(); return }
            if (contentLength < 0) contentLength = 0
            val body = ByteArray(contentLength)
            var off = 0
            if (contentLength > 0) {
                while (off < contentLength) { val r = ins.read(body, off, contentLength - off); if (r == -1) break; off += r }
                if (off != contentLength) { writeResp(outs, 400, null); sock.close(); return } // 读不满 -> 拒绝
            }
            // Token 校验（所有请求，含 initialize/GET/DELETE）。
            if (token.isEmpty() || auth != "Bearer $token") { writeResp(outs, 401, null); sock.close(); return }
            if (method != "POST") { writeResp(outs, 405, null); sock.close(); return }

            val json = try { JSONObject(String(body, Charsets.UTF_8)) } catch (e: Exception) { JSONObject() }
            val hasId = json.has("id") && !json.isNull("id")
            val mid = if (hasId) json.opt("id") else null
            val m = json.optString("method", "")
            if (!hasId) { writeResp(outs, 202, null); sock.close(); return }

            val respObj: JSONObject = when (m) {
                "initialize" -> ok(mid, JSONObject().apply {
                    put("protocolVersion", PROTO)
                    put("capabilities", JSONObject().put("tools", JSONObject()))
                    put("serverInfo", JSONObject().put("name", "star-river-local").put("version", "0.1"))
                })
                "ping" -> ok(mid, JSONObject())
                "tools/list" -> {
                    val arr = JSONArray()
                    synchronized(tools) { for (t in tools.values) arr.put(JSONObject().apply {
                        put("name", t.name); put("description", t.description); put("inputSchema", t.inputSchema())
                    }) }
                    ok(mid, JSONObject().put("tools", arr))
                }
                "tools/call" -> {
                    val params = json.optJSONObject("params") ?: JSONObject()
                    val name = params.optString("name", "")
                    val args = params.optJSONObject("arguments") ?: JSONObject()
                    val tool = synchronized(tools) { tools[name] }
                    if (tool == null) err(mid, -32601, "unknown tool $name")
                    else {
                        val desc = describeArgs(args)
                        val t0 = System.currentTimeMillis()
                        if (tool.isWrite && !ApprovalGate.request(tool.name, desc, "")) {
                            ok(mid, JSONObject().put("isError", true).put("content", JSONArray().put(
                                McpContent.text("【未执行】用户拒绝或审批超时，操作已取消：$name").toJson())))
                        } else {
                            var execErr = false
                            val contents = try { tool.execute(args) } catch (ex: Throwable) {
                                execErr = true
                                listOf(McpContent.text("工具出错：" + (ex.message ?: ex.javaClass.simpleName)))
                            }
                            AppAudit.log("执行 $name #" + (if (execErr) "error" else "ok") + " " + (System.currentTimeMillis() - t0) + "ms")
                            // 结果统一上限；超限置 isError，不静默截断成“成功”
                            var tooBig = false
                            val arr = JSONArray()
                            for (c in contents) {
                                if (c.type == "text") {
                                    val tx = c.text ?: ""
                                    if (tx.length > MAX_RESULT_TEXT) { tooBig = true; break }
                                    arr.put(c.toJson())
                                } else if (c.type == "image") {
                                    val approx = (c.data?.length ?: 0) * 3 / 4
                                    if (approx > MAX_IMAGE_BYTES) { tooBig = true; break }
                                    arr.put(c.toJson())
                                } else arr.put(c.toJson())
                            }
                            val resp = JSONObject().put("content", if (tooBig) JSONArray().put(McpContent.text("结果过大，已拒绝返回（请缩小范围）").toJson()) else arr)
                            if (execErr || tooBig) resp.put("isError", true)
                            ok(mid, resp)
                        }
                    }
                }
                else -> err(mid, -32601, "unknown method $m")
            }
            val bodyOut = respObj.toString().toByteArray(Charsets.UTF_8)
            if (bodyOut.size > MAX_RESP_BODY) { writeResp(outs, 500, null); sock.close(); return }
            writeBytes(outs, 200, bodyOut); sock.close()
        } catch (t: Throwable) { Log.e(TAG, "handle err: " + (t.message ?: "")); try { sock.close() } catch (e: Exception) {} }
    }

    private fun ok(id: Any?, result: JSONObject) = JSONObject().put("jsonrpc", "2.0").put("id", id ?: JSONObject.NULL).put("result", result)
    private fun err(id: Any?, code: Int, msg: String) = JSONObject().put("jsonrpc", "2.0").put("id", id ?: JSONObject.NULL).put("error", JSONObject().put("code", code).put("message", msg))
    private fun writeResp(outs: OutputStream, code: Int, obj: JSONObject?) { writeBytes(outs, code, if (obj == null) ByteArray(0) else obj.toString().toByteArray(Charsets.UTF_8)) }
    private fun writeBytes(outs: OutputStream, code: Int, body: ByteArray) {
        val sb = StringBuilder()
        sb.append("HTTP/1.1 ").append(code).append(' ').append(reason(code)).append("\r\n")
        if (body.isNotEmpty()) sb.append("Content-Type: application/json\r\n")
        sb.append("Content-Length: ").append(body.size).append("\r\nConnection: close\r\n\r\n")
        outs.write(sb.toString().toByteArray(Charsets.UTF_8)); if (body.isNotEmpty()) outs.write(body); outs.flush()
    }
    private fun reason(code: Int) = when (code) { 200 -> "OK"; 202 -> "Accepted"; 400 -> "Bad Request"; 401 -> "Unauthorized"; 405 -> "Method Not Allowed"; 413 -> "Payload Too Large"; 431 -> "Headers Too Large"; 500 -> "Internal Server Error"; else -> "OK" }
}
