package com.starriver.app

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.Semaphore

class McpContent(val type: String, val text: String? = null, val data: String? = null, val mimeType: String? = null) {
    fun toJson(): JSONObject {
        val o = JSONObject().put("type", type)
        if (text != null) o.put("text", text)
        if (data != null) { o.put("data", data); if (mimeType != null) o.put("mimeType", mimeType) }
        return o
    }
    companion object { fun text(s: String) = McpContent("text", text = s) }
}

interface McpTool {
    val name: String
    val description: String
    val isWrite: Boolean get() = false
    fun inputSchema(): JSONObject
    fun execute(args: JSONObject): List<McpContent>
}

private class HttpErr(val code: Int) : Exception()

/**
 * 极简本地 MCP server（无状态、application/json）。
 * 严格 HTTP：请求行必须 POST /mcp HTTP/1.x；头必须完整(空行结束)，EOF/超长/重复/缺失 Authorization 一律拒绝。
 * 资源上限：并发、请求体、头行、单条文本(UTF-8 字节)、累计图片、响应体、整请求时限。
 * Token 校验前置；JSON 解析失败 400。写操作 execute 前经 ApprovalGate 硬阻断。审计仅记事件+脱敏参数。
 */
object LocalMcpServer {
    private const val TAG = "LocalMcpServer"
    const val PORT = 18321
    private const val PROTO = "2025-06-18"
    val endpoint: String get() = "http://127.0.0.1:$PORT/mcp"

    private const val MAX_CONN = 8
    private const val MAX_BODY = 1048576
    private const val MAX_LINE = 8192
    private const val MAX_HEADERS = 64
    private const val MAX_RESULT_TEXT = 131072      // 单条文本 UTF-8 字节上限 128 KiB
    private const val MAX_IMAGE_ONE = 2097152       // 单张图片原始 2 MiB
    private const val MAX_IMAGE_TOTAL = 4194304     // 累计图片原始 4 MiB
    private const val MAX_RESP_BODY = 4194304       // 响应体 4 MiB
    private const val TOTAL_MS = 20000L             // 整请求时限

    private val tools = LinkedHashMap<String, McpTool>()
    private val connPermits = Semaphore(MAX_CONN)
    @Volatile private var started = false
    private var server: ServerSocket? = null
    @Volatile private var token: String = ""

    fun register(t: McpTool) { synchronized(tools) { tools[t.name] = t } }
    fun toolCount(): Int = synchronized(tools) { tools.size }
    fun toolNames(): List<String> = synchronized(tools) { tools.keys.toList() }
    fun token(): String = token

    private fun newToken(): String { val b = ByteArray(24); SecureRandom().nextBytes(b); val sb = StringBuilder(); for (x in b) sb.append(String.format("%02x", x)); return sb.toString() }

    fun ensureStarted(): String {
        if (started) return token
        synchronized(this) {
            if (started) return token
            val t = newToken()
            var ss: ServerSocket? = null
            try {
                ss = ServerSocket(PORT, 16, InetAddress.getByName("127.0.0.1"))
                server = ss; token = t; started = true
                val ssFinal = ss
                Thread({ while (!ssFinal.isClosed) {
                    val s = try { ssFinal.accept() } catch (ex: Throwable) { if (ssFinal.isClosed) break; continue }
                    if (!connPermits.tryAcquire()) { try { s.close() } catch (e: Exception) {} ; continue }
                    try { Thread { try { handle(s) } finally { connPermits.release() } }.start() }
                    catch (ex: Throwable) { try { s.close() } catch (e: Exception) {} ; connPermits.release() }
                } }, "local-mcp-accept").apply { isDaemon = true }.start()
                Log.i(TAG, "local MCP server started at $endpoint"); return token
            } catch (ex: Throwable) {
                Log.e(TAG, "start failed: " + (ex.message ?: ""))
                try { ss?.close() } catch (e: Exception) {}
                server = null; started = false; token = ""; return ""
            }
        }
    }

    private fun describeArgs(args: JSONObject): String {
        if (args.length() == 0) return "（无参数）"
        val sb = StringBuilder(); val it = args.keys()
        while (it.hasNext()) { val k = it.next(); val v = args.opt(k)?.toString() ?: ""; if (sb.isNotEmpty()) sb.append(", "); sb.append(k).append("=").append(v) }
        return sb.toString()
    }
    private fun maskArgs(args: JSONObject): String {
        if (args.length() == 0) return "（无参数）"
        val sb = StringBuilder(); val it = args.keys()
        while (it.hasNext()) { val k = it.next(); val v = args.opt(k); if (sb.isNotEmpty()) sb.append(", "); if (v is Number || v is Boolean) sb.append(k).append("=").append(v) else sb.append(k).append("=***") }
        return sb.toString()
    }

    private class LineRes(val status: Int, val line: String?)   // 0=normal 1=EOF 2=tooLong
    private fun readLine(ins: InputStream, max: Int): LineRes {
        val sb = StringBuilder()
        while (true) {
            val b = ins.read(); if (b == -1) return LineRes(1, if (sb.isEmpty()) null else sb.toString())
            if (b == '\n'.code) { val s = sb.toString(); return LineRes(0, if (s.endsWith("\r")) s.dropLast(1) else s) }
            sb.append(b.toChar()); if (sb.length > max) return LineRes(2, null)
        }
    }

    private fun handle(sock: Socket) {
        var outs: OutputStream? = null
        try {
            val deadline = System.currentTimeMillis() + TOTAL_MS
            sock.soTimeout = 15000
            val ins = sock.getInputStream(); val o = sock.getOutputStream(); outs = o

            val rl = readLine(ins, MAX_LINE)
            if (rl.status != 0) throw HttpErr(if (rl.status == 2) 431 else 400)
            val parts = rl.line!!.split(" ")
            if (parts.size < 3) throw HttpErr(400)
            val method = parts[0]; val target = parts[1]; val ver = parts[2]
            if (method != "POST" || !ver.startsWith("HTTP/1.") || !(target == "/mcp" || target.startsWith("/mcp?"))) throw HttpErr(400)

            var contentLength = -1; var clSeen = false; var authCount = 0; var auth = ""; var transferEnc = false; var hcount = 0
            while (true) {
                val h = readLine(ins, MAX_LINE)
                if (h.status == 1) throw HttpErr(400)          // EOF 但未见空行 -> 头不完整
                if (h.status == 2) throw HttpErr(431)
                val line = h.line!!
                if (line.isEmpty()) break                       // 正常头结束
                hcount++; if (hcount > MAX_HEADERS) throw HttpErr(431)
                val idx = line.indexOf(':'); if (idx <= 0) continue
                val k = line.substring(0, idx).trim().lowercase(); val v = line.substring(idx + 1).trim()
                when (k) {
                    "content-length" -> { if (clSeen) throw HttpErr(400); clSeen = true; contentLength = v.toIntOrNull() ?: -1 }
                    "authorization" -> { authCount++; auth = v }
                    "transfer-encoding" -> transferEnc = true
                }
            }
            if (transferEnc) throw HttpErr(400)
            if (authCount == 0 || authCount > 1) throw HttpErr(400)   // 缺失/重复 Authorization
            if (!auth.startsWith("Bearer ")) throw HttpErr(400)       // 格式非法
            if (clSeen && contentLength < 0) throw HttpErr(400)
            if (contentLength > MAX_BODY) throw HttpErr(413)
            if (contentLength < 0) contentLength = 0
            if (token.isEmpty() || auth != "Bearer $token") throw HttpErr(401)
            if (method != "POST") throw HttpErr(405)

            if (System.currentTimeMillis() > deadline) throw HttpErr(408)
            val remain = (deadline - System.currentTimeMillis()).toInt(); sock.soTimeout = if (remain > 0) remain else 1
            val body = ByteArray(contentLength); var off = 0
            if (contentLength > 0) {
                while (off < contentLength) { val r = ins.read(body, off, contentLength - off); if (r == -1) break; off += r }
                if (off != contentLength) throw HttpErr(400)
            }

            val json = try { JSONObject(String(body, Charsets.UTF_8)) } catch (e: Exception) { throw HttpErr(400) }
            val hasId = json.has("id") && !json.isNull("id")
            val mid = if (hasId) json.opt("id") else null
            val m = json.optString("method", "")
            if (!hasId) { writeResp(o, 202, null); return }

            val respObj: JSONObject = when (m) {
                "initialize" -> ok(mid, JSONObject().apply {
                    put("protocolVersion", PROTO)
                    put("capabilities", JSONObject().put("tools", JSONObject()))
                    put("serverInfo", JSONObject().put("name", "star-river-local").put("version", "0.1"))
                })
                "ping" -> ok(mid, JSONObject())
                "tools/list" -> {
                    val arr = JSONArray()
                    synchronized(tools) { for (t in tools.values) arr.put(JSONObject().apply {
                        put("name", t.name); put("description", t.description); put("inputSchema", t.inputSchema())
                    }) }
                    ok(mid, JSONObject().put("tools", arr))
                }
                "tools/call" -> {
                    val params = json.optJSONObject("params") ?: JSONObject()
                    val name = params.optString("name", "")
                    val args = params.optJSONObject("arguments") ?: JSONObject()
                    val tool = synchronized(tools) { tools[name] }
                    if (tool == null) err(mid, -32601, "unknown tool $name")
                    else {
                        val desc = describeArgs(args); val masked = maskArgs(args); val t0 = System.currentTimeMillis()
                        if (tool.isWrite && !ApprovalGate.request(tool.name, desc, masked)) {
                            ok(mid, JSONObject().put("isError", true).put("content", JSONArray().put(
                                McpContent.text("【未执行】用户拒绝或审批超时，操作已取消：$name").toJson())))
                        } else {
                            var execErr = false
                            val contents = try { tool.execute(args) } catch (ex: Throwable) {
                                execErr = true; listOf(McpContent.text("工具出错：" + (ex.message ?: ex.javaClass.simpleName)))
                            }
                            AppAudit.log("执行 $name #" + (if (execErr) "error" else "ok") + " " + (System.currentTimeMillis() - t0) + "ms")
                            var tooBig = false; var imgTotal = 0L; val arr = JSONArray()
                            for (c in contents) {
                                when (c.type) {
                                    "text" -> { val tx = c.text ?: ""; if (tx.toByteArray(Charsets.UTF_8).size > MAX_RESULT_TEXT) { tooBig = true; break }; arr.put(c.toJson()) }
                                    "image" -> { val approx = (c.data?.length ?: 0) * 3 / 4; if (approx > MAX_IMAGE_ONE) { tooBig = true; break }; imgTotal += approx; if (imgTotal > MAX_IMAGE_TOTAL) { tooBig = true; break }; arr.put(c.toJson()) }
                                    else -> { tooBig = true; break }   // 未知类型拒绝
                                }
                            }
                            val resp = if (tooBig) JSONObject().put("isError", true).put("content", JSONArray().put(McpContent.text("结果过大或类型不支持，已拒绝返回").toJson()))
                                       else JSONObject().put("content", arr)
                            if (execErr) resp.put("isError", true)
                            ok(mid, resp)
                        }
                    }
                }
                else -> err(mid, -32601, "unknown method $m")
            }
            var bodyOut = respObj.toString().toByteArray(Charsets.UTF_8)
            if (bodyOut.size > MAX_RESP_BODY) {
                // 不返回 HTTP 500；改为 JSON-RPC isError 结果
                val fb = ok(mid, JSONObject().put("isError", true).put("content", JSONArray().put(McpContent.text("响应过大，已拒绝返回").toJson())))
                bodyOut = fb.toString().toByteArray(Charsets.UTF_8)
            }
            writeBytes(o, 200, bodyOut)
        } catch (e: HttpErr) {
            try { writeResp(outs, e.code, null) } catch (x: Exception) {}
        } catch (t: Throwable) {
            Log.e(TAG, "handle err: " + (t.message ?: "")); try { writeResp(outs, 400, null) } catch (x: Exception) {}
        } finally { try { sock.close() } catch (x: Exception) {} }
    }

    private fun ok(id: Any?, result: JSONObject) = JSONObject().put("jsonrpc", "2.0").put("id", id ?: JSONObject.NULL).put("result", result)
    private fun err(id: Any?, code: Int, msg: String) = JSONObject().put("jsonrpc", "2.0").put("id", id ?: JSONObject.NULL).put("error", JSONObject().put("code", code).put("message", msg))
    private fun writeResp(outs: OutputStream?, code: Int, obj: JSONObject?) { if (outs == null) return; writeBytes(outs, code, if (obj == null) ByteArray(0) else obj.toString().toByteArray(Charsets.UTF_8)) }
    private fun writeBytes(outs: OutputStream, code: Int, body: ByteArray) {
        val sb = StringBuilder()
        sb.append("HTTP/1.1 ").append(code).append(' ').append(reason(code)).append("\r\n")
        if (body.isNotEmpty()) sb.append("Content-Type: application/json\r\n")
        sb.append("Content-Length: ").append(body.size).append("\r\nConnection: close\r\n\r\n")
        outs.write(sb.toString().toByteArray(Charsets.UTF_8)); if (body.isNotEmpty()) outs.write(body); outs.flush()
    }
    private fun reason(code: Int) = when (code) { 200 -> "OK"; 202 -> "Accepted"; 400 -> "Bad Request"; 401 -> "Unauthorized"; 405 -> "Method Not Allowed"; 408 -> "Request Timeout"; 413 -> "Payload Too Large"; 431 -> "Headers Too Large"; else -> "OK" }
}
