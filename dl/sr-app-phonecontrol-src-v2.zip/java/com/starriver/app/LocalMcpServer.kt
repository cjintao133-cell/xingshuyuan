package com.starriver.app

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit

class McpContent(val type: String, val text: String? = null, val data: String? = null, val mimeType: String? = null) {
    fun toJson(): JSONObject {
        val o = JSONObject().put("type", type)
        if (text != null) o.put("text", text)
        if (data != null) { o.put("data", data); if (mimeType != null) o.put("mimeType", mimeType) }
        return o
    }
    companion object { fun text(s: String) = McpContent("text", text = s) }
}

interface McpTool {
    val name: String
    val description: String
    val isWrite: Boolean get() = false
    fun inputSchema(): JSONObject
    fun execute(args: JSONObject): List<McpContent>
}

private class HttpErr(val code: Int) : Exception()

/**
 * 本地 MCP server。严格 HTTP；整请求 TOTAL_MS 硬性覆盖读取/审批/执行前检查。
 * 资源上限；结果 UTF-8 字节/图片累计；未知类型拒绝；超限走 JSON-RPC isError 不 500。
 * 写操作 execute 前经 ApprovalGate 硬阻断；审计仅事件+脱敏(递归)参数。
 */
object LocalMcpServer {
    private const val TAG = "LocalMcpServer"
    const val PORT = 18321
    private const val PROTO = "2025-06-18"
    val endpoint: String get() = "http://127.0.0.1:$PORT/mcp"

    private const val MAX_CONN = 8
    private const val MAX_BODY = 1048576
    private const val MAX_LINE = 8192
    private const val MAX_HEADERS = 64
    private const val MAX_RESULT_TEXT = 131072
    private const val MAX_IMAGE_ONE = 2097152L
    private const val MAX_IMAGE_TOTAL = 4194304L
    private const val MAX_RESP_BODY = 4194304
    private const val TOTAL_MS = 20000L

    private val tools = LinkedHashMap<String, McpTool>()
    private val connPermits = Semaphore(MAX_CONN)
    private const val MAX_TOOL_MS = 8000L
    private const val MAX_EXEC_THREADS = 4
    // 有界执行器：固定 4 线程 + SynchronousQueue + AbortPolicy（满则拒绝，绝不 CallerRuns/直跑）
    private val exec = java.util.concurrent.ThreadPoolExecutor(
        MAX_EXEC_THREADS, MAX_EXEC_THREADS, 60L, TimeUnit.SECONDS,
        java.util.concurrent.SynchronousQueue<Runnable>(),
        { r -> Thread(r, "mcp-exec").apply { isDaemon = true } },
        java.util.concurrent.ThreadPoolExecutor.AbortPolicy()
    )
    @Volatile private var started = false
    private var server: ServerSocket? = null
    @Volatile private var token: String = ""

    fun register(t: McpTool) { synchronized(tools) { tools[t.name] = t } }
    fun toolCount(): Int = synchronized(tools) { tools.size }
    fun toolNames(): List<String> = synchronized(tools) { tools.keys.toList() }
    fun token(): String = token
    private fun newToken(): String { val b = ByteArray(24); SecureRandom().nextBytes(b); val sb = StringBuilder(); for (x in b) sb.append(String.format("%02x", x)); return sb.toString() }

    fun ensureStarted(): String {
        if (started) return token
        synchronized(this) {
            if (started) return token
            val t = newToken(); var ss: ServerSocket? = null
            try {
                ss = ServerSocket(PORT, 16, InetAddress.getByName("127.0.0.1")); server = ss; token = t; started = true
                val ssFinal = ss
                Thread({ while (!ssFinal.isClosed) {
                    val s = try { ssFinal.accept() } catch (ex: Throwable) { if (ssFinal.isClosed) break; continue }
                    if (!connPermits.tryAcquire()) { try { s.close() } catch (e: Exception) {} ; continue }
                    try { Thread { try { handle(s) } finally { connPermits.release() } }.start() }
                    catch (ex: Throwable) { try { s.close() } catch (e: Exception) {} ; connPermits.release() }
                } }, "local-mcp-accept").apply { isDaemon = true }.start()
                Log.i(TAG, "local MCP server started at $endpoint"); return token
            } catch (ex: Throwable) {
                Log.e(TAG, "start failed: " + (ex.message ?: ""))
                try { ss?.close() } catch (e: Exception) {}
                server = null; started = false; token = ""; return ""
            }
        }
    }

    private fun describeArgs(args: JSONObject): String {
        if (args.length() == 0) return "（无参数）"
        val sb = StringBuilder(); val it = args.keys()
        while (it.hasNext()) { val k = it.next(); val v = args.opt(k)?.toString() ?: ""; if (sb.isNotEmpty()) sb.append(", "); sb.append(k).append("=").append(v) }
        return sb.toString()
    }

    /** 递归脱敏：对象/数组里的字符串值一律 ***，数值/布尔保留；键名保留。 */
    private fun maskAny(v: Any?): String = when (v) {
        null, JSONObject.NULL -> "null"
        is JSONObject -> { val sb = StringBuilder("{"); val it = v.keys(); var first = true
            while (it.hasNext()) { val k = it.next(); if (!first) sb.append(", "); first = false; sb.append(k).append("=").append(maskAny(v.opt(k))) }
            sb.append("}"); sb.toString() }
        is JSONArray -> { val sb = StringBuilder("["); for (i in 0 until v.length()) { if (i > 0) sb.append(", "); sb.append(maskAny(v.opt(i))) }; sb.append("]"); sb.toString() }
        is Number, is Boolean -> v.toString()
        else -> "***"
    }
    private fun maskArgs(args: JSONObject): String = if (args.length() == 0) "（无参数）" else maskAny(args)

    private fun remaining(deadline: Long): Long = deadline - System.currentTimeMillis()

    private class LineRes(val status: Int, val line: String?)   // 0 normal 1 EOF 2 tooLong
    private fun readLine(sock: Socket, ins: InputStream, max: Int, deadline: Long): LineRes {
        val sb = StringBuilder()
        while (true) {
            val r = remaining(deadline); if (r <= 0) throw HttpErr(408)
            sock.soTimeout = r.toInt().coerceIn(1, 15000)
            val b = ins.read(); if (b == -1) return LineRes(1, if (sb.isEmpty()) null else sb.toString())
            if (b == '\n'.code) { val s = sb.toString(); return LineRes(0, if (s.endsWith("\r")) s.dropLast(1) else s) }
            sb.append(b.toChar()); if (sb.length > max) return LineRes(2, null)
        }
    }

    private fun readBody(sock: Socket, ins: InputStream, len: Int, deadline: Long): ByteArray {
        val body = ByteArray(len); var off = 0
        while (off < len) {
            val r = remaining(deadline); if (r <= 0) throw HttpErr(408)
            sock.soTimeout = r.toInt().coerceIn(1, 15000)
            val n = ins.read(body, off, len - off); if (n == -1) break; off += n
        }
        if (off != len) throw HttpErr(400)
        return body
    }

    private fun handle(sock: Socket) {
        var outs: OutputStream? = null
        try {
            val deadline = System.currentTimeMillis() + TOTAL_MS
            val ins = sock.getInputStream(); val o = sock.getOutputStream(); outs = o

            val rl = readLine(sock, ins, MAX_LINE, deadline)
            if (rl.status != 0) throw HttpErr(if (rl.status == 2) 431 else 400)
            val parts = rl.line!!.split(" ")
            if (parts.size != 3) throw HttpErr(400)
            val method = parts[0]; val target = parts[1]; val ver = parts[2]
            if (method != "POST") throw HttpErr(405)
            if (ver != "HTTP/1.0" && ver != "HTTP/1.1") throw HttpErr(400)
            if (!(target == "/mcp" || target.startsWith("/mcp?"))) throw HttpErr(400)

            var contentLength = -1; var clSeen = false; var authCount = 0; var auth = ""; var transferEnc = false; var hcount = 0
            while (true) {
                val h = readLine(sock, ins, MAX_LINE, deadline)
                if (h.status == 1) throw HttpErr(400)         // EOF 未见空行
                if (h.status == 2) throw HttpErr(431)
                val line = h.line!!
                if (line.isEmpty()) break                      // 头结束
                hcount++; if (hcount > MAX_HEADERS) throw HttpErr(431)
                val idx = line.indexOf(':'); if (idx <= 0) throw HttpErr(400)   // 畸形头拒绝
                val k = line.substring(0, idx).trim().lowercase(); val v = line.substring(idx + 1).trim()
                if (k.isEmpty()) throw HttpErr(400)
                when (k) {
                    "content-length" -> { if (clSeen) throw HttpErr(400); clSeen = true; contentLength = v.toIntOrNull() ?: -1 }
                    "authorization" -> { authCount++; auth = v }
                    "transfer-encoding" -> transferEnc = true
                }
            }
            if (transferEnc) throw HttpErr(400)
            if (authCount == 0 || authCount > 1) throw HttpErr(400)
            if (!auth.startsWith("Bearer ")) throw HttpErr(400)
            if (clSeen && contentLength < 0) throw HttpErr(400)
            if (contentLength > MAX_BODY) throw HttpErr(413)
            if (contentLength < 0) contentLength = 0
            if (token.isEmpty() || auth != "Bearer $token") throw HttpErr(401)

            val body = if (contentLength > 0) readBody(sock, ins, contentLength, deadline) else ByteArray(0)

            val json = try { JSONObject(String(body, Charsets.UTF_8)) } catch (e: Exception) { throw HttpErr(400) }
            val hasId = json.has("id") && !json.isNull("id")
            val mid = if (hasId) json.opt("id") else null
            val m = json.optString("method", "")
            if (!hasId) { writeResp(o, 202, null); return }

            val respObj: JSONObject = when (m) {
                "initialize" -> ok(mid, JSONObject().apply {
                    put("protocolVersion", PROTO)
                    put("capabilities", JSONObject().put("tools", JSONObject()))
                    put("serverInfo", JSONObject().put("name", "star-river-local").put("version", "0.1"))
                })
                "ping" -> ok(mid, JSONObject())
                "tools/list" -> {
                    val arr = JSONArray()
                    synchronized(tools) { for (t in tools.values) arr.put(JSONObject().apply {
                        put("name", t.name); put("description", t.description); put("inputSchema", t.inputSchema())
                    }) }
                    ok(mid, JSONObject().put("tools", arr))
                }
                "tools/call" -> {
                    val params = json.optJSONObject("params") ?: JSONObject()
                    val name = params.optString("name", "")
                    val args = params.optJSONObject("arguments") ?: JSONObject()
                    val tool = synchronized(tools) { tools[name] }
                    if (tool == null) err(mid, -32601, "unknown tool $name")
                    else {
                        val desc = describeArgs(args); val masked = maskArgs(args); val t0 = System.currentTimeMillis()
                        if (tool.isWrite) {
                            if (!ApprovalGate.request(tool.name, desc, masked, deadline)) {
                                val deny = ok(mid, JSONObject().put("isError", true).put("content", JSONArray().put(
                                    McpContent.text("【未执行】用户拒绝或审批超时，操作已取消：$name").toJson())))
                                writeBytes(o, 200, deny.toString().toByteArray(Charsets.UTF_8)); return
                            }
                        }
                        if (remaining(deadline) <= 0) throw HttpErr(408)   // 执行前再查 deadline
                        val execTimeout = minOf(MAX_TOOL_MS, remaining(deadline)).coerceAtLeast(1L)
                        val fut: java.util.concurrent.Future<Pair<List<McpContent>, Throwable?>> = try {
                            exec.submit(java.util.concurrent.Callable<Pair<List<McpContent>, Throwable?>> {
                                try { Pair(tool.execute(args), null) }
                                catch (ie: InterruptedException) { Thread.currentThread().interrupt(); throw ie }   // 不吞中断
                                catch (ex: Exception) { Pair(emptyList<McpContent>(), ex) }   // 只接普通异常，不吞 Error
                            })
                        } catch (re: java.util.concurrent.RejectedExecutionException) {
                            AppAudit.log("执行 $name #rejected(线程池满) " + (System.currentTimeMillis() - t0) + "ms")
                            val busy = ok(mid, JSONObject().put("isError", true).put("content", JSONArray().put(
                                McpContent.text("系统繁忙（手机控制执行队列已满），请稍后重试").toJson())))
                            writeBytes(o, 200, busy.toString().toByteArray(Charsets.UTF_8)); return
                        }
                        var execErr = false; var timedOut = false; var interrupted = false
                        val contents: List<McpContent> = try {
                            val res = fut.get(execTimeout, TimeUnit.MILLISECONDS)
                            val e = res.second
                            if (e != null) { execErr = true; listOf(McpContent.text("工具出错：" + (e.message ?: e.javaClass.simpleName))) } else res.first
                        } catch (te: java.util.concurrent.TimeoutException) {
                            fut.cancel(true); timedOut = true
                            listOf(McpContent.text("操作超时（>${execTimeout}ms），已中断等待；无法确认手机上是否已执行该操作，请自行检查。"))
                        } catch (ie: InterruptedException) {
                            fut.cancel(true); Thread.currentThread().interrupt(); interrupted = true
                            listOf(McpContent.text("请求被中断，已停止等待；无法确认手机操作是否已经执行，请检查设备状态。"))
                        } catch (e: java.util.concurrent.ExecutionException) {
                            val cause = e.cause
                            if (cause is Error) throw cause                 // 解包并把 JVM Error 原样上抛
                            execErr = true; listOf(McpContent.text("工具出错：" + (cause?.message ?: e.message ?: "未知错误")))
                        } catch (e: Exception) {
                            execErr = true; listOf(McpContent.text("工具出错：" + (e.message ?: e.javaClass.simpleName)))
                        }
                        val status = when { timedOut -> "timeout_uncertain"; interrupted -> "interrupted_uncertain"; execErr -> "error"; else -> "ok" }
                        AppAudit.log("执行 $name #$status " + (System.currentTimeMillis() - t0) + "ms")
                        var tooBig = false; var imgTotal = 0L; val arr = JSONArray()
                        for (c in contents) {
                            when (c.type) {
                                "text" -> { val tx = c.text ?: ""; if (tx.toByteArray(Charsets.UTF_8).size > MAX_RESULT_TEXT) { tooBig = true; break }; arr.put(c.toJson()) }
                                "image" -> {
                                    val data = c.data; val mime = (c.mimeType ?: "").lowercase()
                                    if (data.isNullOrBlank()) { tooBig = true; break }
                                    if (mime !in setOf("image/png", "image/jpeg", "image/jpg", "image/webp")) { tooBig = true; break }
                                    // 先按原始长度预检（避免 replace 前分配超大字符串）；要求无换行 Base64
                                    if (data.length.toLong() > (MAX_IMAGE_ONE * 4L / 3L + 16L)) { tooBig = true; break }
                                    if (data.indexOf('\n') >= 0 || data.indexOf('\r') >= 0) { tooBig = true; break }
                                    val norm = data
                                    if (norm.length % 4 != 0) { tooBig = true; break }
                                    if (!norm.matches(Regex("^[A-Za-z0-9+/]+={0,2}$"))) { tooBig = true; break }
                                    val decoded = try { android.util.Base64.decode(norm, android.util.Base64.DEFAULT) } catch (e: Exception) { null }
                                    if (decoded == null) { tooBig = true; break }
                                    // 规范性校验：重新 NO_WRAP 编码必须与原文逐字节一致
                                    val canonical = try { android.util.Base64.encodeToString(decoded, android.util.Base64.NO_WRAP) } catch (e: Exception) { null }
                                    if (canonical == null || canonical != norm) { tooBig = true; break }
                                    val a = decoded.size.toLong()
                                    if (a > MAX_IMAGE_ONE) { tooBig = true; break }
                                    imgTotal += a; if (imgTotal > MAX_IMAGE_TOTAL) { tooBig = true; break }
                                    arr.put(c.toJson())
                                }
                                else -> { tooBig = true; break }
                            }
                        }
                        val resp = if (tooBig) JSONObject().put("isError", true).put("content", JSONArray().put(McpContent.text("结果过大或类型不支持，已拒绝返回").toJson()))
                                   else JSONObject().put("content", arr)
                        if (execErr || timedOut || interrupted) resp.put("isError", true)
                        ok(mid, resp)
                    }
                }
                else -> err(mid, -32601, "unknown method $m")
            }
            if (remaining(deadline) <= 0) throw HttpErr(408)   // 写出前查 deadline
            var bodyOut = respObj.toString().toByteArray(Charsets.UTF_8)
            if (bodyOut.size > MAX_RESP_BODY) {
                bodyOut = ok(mid, JSONObject().put("isError", true).put("content", JSONArray().put(McpContent.text("响应过大，已拒绝返回").toJson()))).toString().toByteArray(Charsets.UTF_8)
            }
            writeBytes(o, 200, bodyOut)
        } catch (e: HttpErr) {
            try { writeResp(outs, e.code, null) } catch (x: Exception) {}
        } catch (t: Throwable) {
            Log.e(TAG, "handle err: " + (t.message ?: "")); try { writeResp(outs, 400, null) } catch (x: Exception) {}
        } finally { try { sock.close() } catch (x: Exception) {} }
    }

    private fun ok(id: Any?, result: JSONObject) = JSONObject().put("jsonrpc", "2.0").put("id", id ?: JSONObject.NULL).put("result", result)
    private fun err(id: Any?, code: Int, msg: String) = JSONObject().put("jsonrpc", "2.0").put("id", id ?: JSONObject.NULL).put("error", JSONObject().put("code", code).put("message", msg))
    private fun writeResp(outs: OutputStream?, code: Int, obj: JSONObject?) { if (outs == null) return; writeBytes(outs, code, if (obj == null) ByteArray(0) else obj.toString().toByteArray(Charsets.UTF_8)) }
    private fun writeBytes(outs: OutputStream, code: Int, body: ByteArray) {
        val sb = StringBuilder()
        sb.append("HTTP/1.1 ").append(code).append(' ').append(reason(code)).append("\r\n")
        if (body.isNotEmpty()) sb.append("Content-Type: application/json\r\n")
        sb.append("Content-Length: ").append(body.size).append("\r\nConnection: close\r\n\r\n")
        outs.write(sb.toString().toByteArray(Charsets.UTF_8)); if (body.isNotEmpty()) outs.write(body); outs.flush()
    }
    private fun reason(code: Int) = when (code) { 200 -> "OK"; 202 -> "Accepted"; 400 -> "Bad Request"; 401 -> "Unauthorized"; 405 -> "Method Not Allowed"; 408 -> "Request Timeout"; 413 -> "Payload Too Large"; 431 -> "Headers Too Large"; else -> "OK" }
}
