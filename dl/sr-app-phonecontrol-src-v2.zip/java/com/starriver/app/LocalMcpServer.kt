package com.starriver.app

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.Semaphore

/** MCP 工具结果内容块：type=text(text) 或 type=image(data base64 + mimeType)。 */
class McpContent(val type: String, val text: String? = null, val data: String? = null, val mimeType: String? = null) {
    fun toJson(): JSONObject {
        val o = JSONObject().put("type", type)
        if (text != null) o.put("text", text)
        if (data != null) { o.put("data", data); if (mimeType != null) o.put("mimeType", mimeType) }
        return o
    }
    companion object { fun text(s: String) = McpContent("text", text = s) }
}

/** 一个可被 MCP 暴露的工具。isWrite=true 的工具在执行前必须经 ApprovalGate 硬阻断审批。 */
interface McpTool {
    val name: String
    val description: String
    val isWrite: Boolean get() = false
    fun inputSchema(): JSONObject
    fun execute(args: JSONObject): List<McpContent>
}

/**
 * 极简本地 MCP server（无状态、纯 application/json，不实现 SSE/session）。
 * 只绑 127.0.0.1；所有请求强制校验 Authorization: Bearer <进程内随机 token>，否则 401。
 * 资源防护：最大并发连接、请求体上限、请求头行数/长度上限。
 * 写操作在 execute 前经 ApprovalGate 硬阻断审批。审计只记事件，不记正文/参数/返回。
 */
object LocalMcpServer {
    private const val TAG = "LocalMcpServer"
    const val PORT = 18321
    private const val PROTO = "2025-06-18"
    val endpoint: String get() = "http://127.0.0.1:$PORT/mcp"

    private const val MAX_CONN = 8
    private const val MAX_BODY = 1 shl 20        // 1 MiB
    private const val MAX_LINE = 8 * 1024        // 单行 8 KiB
    private const val MAX_HEADERS = 64

    private val tools = LinkedHashMap<String, McpTool>()
    private val connPermits = Semaphore(MAX_CONN)
    @Volatile private var started = false
    private var server: ServerSocket? = null
    @Volatile private var token: String = ""

    fun register(t: McpTool) { synchronized(tools) { tools[t.name] = t } }
    fun toolCount(): Int = synchronized(tools) { tools.size }
    fun toolNames(): List<String> = synchronized(tools) { tools.keys.toList() }
    fun token(): String = token

    private fun newToken(): String {
        val b = ByteArray(24); SecureRandom().nextBytes(b)
        val sb = StringBuilder(); for (x in b) sb.append(String.format("%02x", x)); return sb.toString()
    }

    /** 启动（幂等）。成功返回当前 token；绑定失败返回空串且不标记 started（调用方可据此判定失败）。 */
    fun ensureStarted(): String {
        if (started) return token
        synchronized(this) {
            if (started) return token
            val t = newToken()
            try {
                val ss = ServerSocket(PORT, 16, InetAddress.getByName("127.0.0.1"))
                server = ss
                token = t
                started = true
                Thread({
                    while (!ss.isClosed) {
                        val s = try { ss.accept() } catch (ex: Throwable) { if (ss.isClosed) break; continue }
                        if (!connPermits.tryAcquire()) { try { s.close() } catch (e: Exception) {} ; continue }
                        Thread { try { handle(s) } finally { connPermits.release() } }.start()
                    }
                }, "local-mcp-accept").apply { isDaemon = true }.start()
                Log.i(TAG, "local MCP server started at $endpoint")
                return token
            } catch (ex: Throwable) {
                Log.e(TAG, "start failed: " + (ex.message ?: ""))
                started = false; token = ""; return ""
            }
        }
    }

    private fun describeArgs(args: JSONObject): String {
        if (args.length() == 0) return "（无参数）"
        val sb = StringBuilder(); val it = args.keys()
        while (it.hasNext()) {
            val k = it.next(); var v = args.opt(k)?.toString() ?: ""
            if (v.length > 40) v = v.take(40) + "…"
            if (sb.isNotEmpty()) sb.append(", ")
            sb.append(k).append("=").append(v)
        }
        return sb.toString()
    }

    /** 掩码版参数摘要（仅用于内部需要时；审计不写它）。字符串值一律 ***。 */
    private fun maskArgs(args: JSONObject): String {
        if (args.length() == 0) return "（无参数）"
        val sb = StringBuilder(); val it = args.keys()
        while (it.hasNext()) {
            val k = it.next(); val v = args.opt(k)
            if (sb.isNotEmpty()) sb.append(", ")
            if (v is Number || v is Boolean) sb.append(k).append("=").append(v) else sb.append(k).append("=***")
        }
        return sb.toString()
    }

    private fun handle(sock: Socket) {
        try {
            sock.soTimeout = 15000
            val ins = sock.getInputStream(); val outs = sock.getOutputStream()
            val reqLine = readLine(ins, MAX_LINE) ?: run { sock.close(); return }
            val method = reqLine.split(" ").getOrNull(0) ?: ""
            var contentLength = -1; var auth = ""; var hcount = 0
            while (true) {
                val h = readLine(ins, MAX_LINE) ?: break
                if (h.isEmpty()) break
                hcount++; if (hcount > MAX_HEADERS) { writeResp(outs, 431, null); sock.close(); return }
                val idx = h.indexOf(':'); if (idx <= 0) continue
                val k = h.substring(0, idx).trim().lowercase(); val v = h.substring(idx + 1).trim()
                if (k == "content-length") contentLength = v.toIntOrNull() ?: -1
                if (k == "authorization") auth = v
            }
            if (contentLength > MAX_BODY) { writeResp(outs, 413, null); sock.close(); return }
            if (contentLength < 0) contentLength = 0
            val body = if (contentLength > 0) readN(ins, contentLength) else ByteArray(0)
            // Token 校验：所有请求（含 initialize/GET/DELETE）都必须带正确 Bearer。
            if (token.isEmpty() || auth != "Bearer $token") { writeResp(outs, 401, null); sock.close(); return }
            if (method != "POST") { writeResp(outs, 405, null); sock.close(); return }

            val json = try { JSONObject(String(body, Charsets.UTF_8)) } catch (e: Exception) { JSONObject() }
            val hasId = json.has("id") && !json.isNull("id")
            val mid = if (hasId) json.opt("id") else null
            val m = json.optString("method", "")
            if (!hasId) { writeResp(outs, 202, null); sock.close(); return }

            val respObj: JSONObject = when (m) {
                "initialize" -> ok(mid, JSONObject().apply {
                    put("protocolVersion", PROTO)
                    put("capabilities", JSONObject().put("tools", JSONObject()))
                    put("serverInfo", JSONObject().put("name", "star-river-local").put("version", "0.1"))
                })
                "ping" -> ok(mid, JSONObject())
                "tools/list" -> {
                    val arr = JSONArray()
                    synchronized(tools) { for (t in tools.values) arr.put(JSONObject().apply {
                        put("name", t.name); put("description", t.description); put("inputSchema", t.inputSchema())
                    }) }
                    ok(mid, JSONObject().put("tools", arr))
                }
                "tools/call" -> {
                    val params = json.optJSONObject("params") ?: JSONObject()
                    val name = params.optString("name", "")
                    val args = params.optJSONObject("arguments") ?: JSONObject()
                    val tool = synchronized(tools) { tools[name] }
                    if (tool == null) err(mid, -32601, "unknown tool $name")
                    else {
                        val desc = describeArgs(args)
                        val t0 = System.currentTimeMillis()
                        // 写操作：执行前硬阻断审批，模型无法绕过（只能走 tools/call）。
                        if (tool.isWrite && !ApprovalGate.request(tool.name, desc, "")) {
                            ok(mid, JSONObject().put("isError", true).put("content", JSONArray().put(
                                McpContent.text("【未执行】用户拒绝或审批超时，操作已取消：$name").toJson())))
                        } else {
                            var okExec = true
                            val contents = try { tool.execute(args) } catch (ex: Throwable) {
                                okExec = false
                                listOf(McpContent.text("工具出错：" + (ex.message ?: ex.javaClass.simpleName)))
                            }
                            AppAudit.log("执行 $name #" + (if (okExec) "ok" else "error") + " " + (System.currentTimeMillis() - t0) + "ms")
                            val arr = JSONArray(); for (c in contents) arr.put(c.toJson())
                            ok(mid, JSONObject().put("content", arr))
                        }
                    }
                }
                else -> err(mid, -32601, "unknown method $m")
            }
            writeResp(outs, 200, respObj); sock.close()
        } catch (t: Throwable) { Log.e(TAG, "handle err: " + (t.message ?: "")); try { sock.close() } catch (e: Exception) {} }
    }

    private fun ok(id: Any?, result: JSONObject) = JSONObject().put("jsonrpc", "2.0").put("id", id ?: JSONObject.NULL).put("result", result)
    private fun err(id: Any?, code: Int, msg: String) = JSONObject().put("jsonrpc", "2.0").put("id", id ?: JSONObject.NULL).put("error", JSONObject().put("code", code).put("message", msg))
    private fun writeResp(outs: OutputStream, code: Int, obj: JSONObject?) {
        val body = if (obj == null) ByteArray(0) else obj.toString().toByteArray(Charsets.UTF_8)
        val sb = StringBuilder()
        sb.append("HTTP/1.1 ").append(code).append(' ').append(reason(code)).append("\r\n")
        if (obj != null) sb.append("Content-Type: application/json\r\n")
        sb.append("Content-Length: ").append(body.size).append("\r\nConnection: close\r\n\r\n")
        outs.write(sb.toString().toByteArray(Charsets.UTF_8)); if (body.isNotEmpty()) outs.write(body); outs.flush()
    }
    private fun reason(code: Int) = when (code) { 200 -> "OK"; 202 -> "Accepted"; 401 -> "Unauthorized"; 405 -> "Method Not Allowed"; 413 -> "Payload Too Large"; 431 -> "Headers Too Large"; else -> "OK" }
    private fun readLine(ins: InputStream, max: Int): String? {
        val sb = StringBuilder()
        while (true) {
            val b = ins.read(); if (b == -1) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) { val s = sb.toString(); return if (s.endsWith("\r")) s.dropLast(1) else s }
            sb.append(b.toChar()); if (sb.length > max) return null
        }
    }
    private fun readN(ins: InputStream, n: Int): ByteArray {
        val buf = ByteArray(n); var off = 0
        while (off < n) { val r = ins.read(buf, off, n - off); if (r == -1) break; off += r }; return buf
    }
}
