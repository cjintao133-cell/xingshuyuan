package com.starriver.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.compose.runtime.mutableStateOf
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.locks.ReentrantLock

/** 审计日志：审批与执行留痕（filesDir/audit.log，>256KB 轮转）。不写 token/完整输入。 */
object AppAudit {
    @Volatile private var dir: File? = null
    fun init(ctx: Context) { if (dir == null) dir = ctx.filesDir }
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault())
    @Synchronized
    fun log(line: String) {
        val msg = fmt.format(Date()) + " " + line
        Log.i("StarRiverAudit", msg)
        val d = dir ?: return
        try {
            val f = File(d, "audit.log")
            if (f.exists() && f.length() > 256 * 1024) { val old = File(d, "audit.1.log"); if (old.exists()) old.delete(); f.renameTo(old) }
            f.appendText(msg + "\n")
        } catch (t: Throwable) { }
    }
}

data class ApprovalReq(val id: Long, val tool: String, val userTarget: String)
private class Pending(val id: Long) { val latch = CountDownLatch(1); val approved = AtomicBoolean(false) }

/**
 * 手机写操作审批门。所有等待都受调用方传入的绝对 deadline 约束：
 *  - tryLock 用 min(剩余,3s)；拿到锁后再核剩余，不足以完成审批即拒绝（不人为延长）。
 *  - await 时长 = 剩余预算（≤ TOTAL），超时=拒绝。
 *  - approve/deny 按 id 命中才生效；迟到/重复点击无害。
 */
object ApprovalGate {
    private val seq = AtomicLong()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val serial = ReentrantLock(true)
    private val stateLock = Any()
    @Volatile private var pending: Pending? = null
    val current = mutableStateOf<ApprovalReq?>(null)

    private fun remaining(deadline: Long) = deadline - System.currentTimeMillis()

    /** deadline = 绝对 System.currentTimeMillis 截止点。返回 true=批准且在预算内。 */
    fun request(tool: String, userTarget: String, logTarget: String, deadline: Long): Boolean {
        val waitMs = remaining(deadline)
        if (waitMs <= 0) { AppAudit.log("审批跳过：已超总时限"); return false }
        val got2 = try { serial.tryLock(minOf(waitMs, 3000L), TimeUnit.MILLISECONDS) } catch (e: InterruptedException) { Thread.currentThread().interrupt(); false }
        if (!got2) { AppAudit.log("审批繁忙(排队超时)，拒绝执行"); return false }
        try {
            val left = remaining(deadline)
            if (left <= 500) { AppAudit.log("审批跳过：剩余预算不足(${left}ms)，拒绝执行"); return false }
            val id = seq.incrementAndGet(); val p = Pending(id)
            synchronized(stateLock) { pending = p }
            mainHandler.post { current.value = ApprovalReq(id, tool, userTarget) }
            AppAudit.log("审批请求 #$id $tool | $logTarget")
            val got = try { p.latch.await(left, TimeUnit.MILLISECONDS) } catch (e: InterruptedException) { Thread.currentThread().interrupt(); false }
            val approved = got && p.approved.get()
            synchronized(stateLock) { if (pending === p) pending = null }
            mainHandler.post { if (current.value?.id == id) current.value = null }
            val why = if (!got) "超时" else if (approved) "批准" else "拒绝"
            AppAudit.log("审批结果 #$id $why -> " + (if (approved) "执行" else "不执行"))
            return approved
        } finally { serial.unlock() }
    }

    fun approve(id: Long) { decide(id, true) }
    fun deny(id: Long) { decide(id, false) }
    private fun decide(id: Long, ok: Boolean) {
        synchronized(stateLock) { val p = pending ?: return; if (p.id != id) return; p.approved.set(ok); p.latch.countDown() }
    }
}
