package com.starriver.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.compose.runtime.mutableStateOf
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.locks.ReentrantLock

/** 审计日志：审批与执行都留痕（filesDir/audit.log，>256KB 轮转）。不写 token/完整输入。 */
object AppAudit {
    @Volatile private var dir: File? = null
    fun init(ctx: Context) { if (dir == null) dir = ctx.filesDir }
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault())
    @Synchronized
    fun log(line: String) {
        val msg = fmt.format(Date()) + " " + line
        Log.i("StarRiverAudit", msg)
        val d = dir ?: return
        try {
            val f = File(d, "audit.log")
            if (f.exists() && f.length() > 256 * 1024) {
                val old = File(d, "audit.1.log"); if (old.exists()) old.delete(); f.renameTo(old)
            }
            f.appendText(msg + "\n")
        } catch (t: Throwable) { }
    }
}

/** 待审批请求。userTarget=给用户看的完整动作。 */
data class ApprovalReq(val id: Long, val tool: String, val userTarget: String)

private class Pending(val id: Long) {
    val latch = CountDownLatch(1)
    val approved = AtomicBoolean(false)
}

/**
 * 手机写操作审批门（执行前硬阻断）。关键设计（避免死锁/错批/并发）：
 *  - serial：公平可重入锁，request() 全程持有以串行化"同一时刻只审批一个"；approve/deny 不碰它 → 不会死锁。
 *  - stateLock：仅保护 pending 指针的短临界区；approve/deny 在其中按 id 命中才 countDown。
 *  - request() 在 await 时**不持有任何 approve 需要的锁**（只持 serial，approve 不需要 serial）。
 *  - approve(id)/deny(id) 只对 pending.id==id 生效 → 超时后迟到的批准不会误批下一条；重复点击无害。
 */
object ApprovalGate {
    private val seq = AtomicLong()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val serial = ReentrantLock(true)
    private val stateLock = Any()
    @Volatile private var pending: Pending? = null

    val current = mutableStateOf<ApprovalReq?>(null)

    fun request(tool: String, userTarget: String, logTarget: String, timeoutMs: Long = 25000): Boolean {
        serial.lock()  // 串行化：同刻仅一条在等；approve/deny 不取此锁
        try {
            val id = seq.incrementAndGet()
            val p = Pending(id)
            synchronized(stateLock) { pending = p }
            mainHandler.post { current.value = ApprovalReq(id, tool, userTarget) }
            AppAudit.log("审批请求 #$id $tool | $logTarget")
            val got = try { p.latch.await(timeoutMs, TimeUnit.MILLISECONDS) } catch (e: InterruptedException) { false }
            val approved = got && p.approved.get()
            synchronized(stateLock) { if (pending === p) pending = null }
            mainHandler.post { if (current.value?.id == id) current.value = null }
            val why = if (!got) "超时" else if (approved) "批准" else "拒绝"
            AppAudit.log("审批结果 #$id $why -> " + (if (approved) "执行" else "不执行"))
            return approved
        } finally { serial.unlock() }
    }

    fun approve(id: Long) { decide(id, true) }
    fun deny(id: Long) { decide(id, false) }
    private fun decide(id: Long, ok: Boolean) {
        synchronized(stateLock) {
            val p = pending ?: return
            if (p.id != id) return
            p.approved.set(ok); p.latch.countDown()
        }
    }
}
