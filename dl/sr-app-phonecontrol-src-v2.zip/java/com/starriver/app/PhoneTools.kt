package com.starriver.app

import android.content.Context
import android.content.Intent
import android.util.Base64
import org.json.JSONObject

private fun schemaOf(vararg props: Pair<String, String>, required: List<String> = emptyList()): JSONObject {
    val properties = JSONObject(); for ((k, t) in props) properties.put(k, JSONObject().put("type", t))
    return JSONObject().put("type", "object").put("properties", properties).put("required", org.json.JSONArray(required))
}
private fun str(args: JSONObject, k: String): String? = if (args.has(k) && !args.isNull(k)) args.optString(k) else null
private fun int(args: JSONObject, k: String): Int? = if (args.has(k) && !args.isNull(k)) args.optInt(k) else null

/** echo：协议自检。 */
class EchoTool : McpTool {
    override val name = "echo"; override val description = "回显输入文本（协议自检用）"
    override fun inputSchema() = schemaOf("text" to "string", required = listOf("text"))
    override fun execute(args: JSONObject) = listOf(McpContent.text("ECHO: " + (str(args, "text") ?: "")))
}

/** 读屏：看当前手机界面元素。 */
class PhoneScreenTool : McpTool {
    override val name = "phone_screen"; override val description = "读取当前手机屏幕上的文字元素（编号+文字+坐标+是否可点），用于“看”现在是什么界面。操作手机前先调它。"
    override fun inputSchema() = schemaOf()
    override fun execute(args: JSONObject) = listOf(McpContent.text(DeviceCtrl.dump()))
}

class PhoneTapTextTool : McpTool {
    override val isWrite = true
    override val name = "phone_tap_text"; override val description = "在当前界面上，按文字（或描述）包含某关键字的元素上点击一下。参数 text。"
    override fun inputSchema() = schemaOf("text" to "string", required = listOf("text"))
    override fun execute(args: JSONObject): List<McpContent> {
        val t = str(args, "text") ?: return listOf(McpContent.text("错误：缺少 text"))
        return listOf(McpContent.text(DeviceCtrl.tapText(t)))
    }
}

class PhoneTapTool : McpTool {
    override val isWrite = true
    override val name = "phone_tap"; override val description = "在屏幕坐标 (x,y) 点一下（像素）。"
    override fun inputSchema() = schemaOf("x" to "integer", "y" to "integer", required = listOf("x", "y"))
    override fun execute(args: JSONObject): List<McpContent> {
        val x = int(args, "x") ?: return listOf(McpContent.text("错误：缺少 x"))
        val y = int(args, "y") ?: return listOf(McpContent.text("错误：缺少 y"))
        return listOf(McpContent.text(DeviceCtrl.tap(x, y)))
    }
}

class PhoneSwipeTool : McpTool {
    override val isWrite = true
    override val name = "phone_swipe"; override val description = "从 (x1,y1) 滑到 (x2,y2)，duration_ms 可选（默认300）。用于翻页/滚动/解锁。"
    override fun inputSchema() = schemaOf("x1" to "integer", "y1" to "integer", "x2" to "integer", "y2" to "integer", "duration_ms" to "integer", required = listOf("x1", "y1", "x2", "y2"))
    override fun execute(args: JSONObject): List<McpContent> {
        val x1 = int(args, "x1") ?: return listOf(McpContent.text("错误：缺少 x1"))
        val y1 = int(args, "y1") ?: return listOf(McpContent.text("错误：缺少 y1"))
        val x2 = int(args, "x2") ?: return listOf(McpContent.text("错误：缺少 x2"))
        val y2 = int(args, "y2") ?: return listOf(McpContent.text("错误：缺少 y2"))
        return listOf(McpContent.text(DeviceCtrl.swipe(x1, y1, x2, y2, (int(args, "duration_ms") ?: 300).toLong())))
    }
}

class PhoneTypeTool : McpTool {
    override val isWrite = true
    override val name = "phone_type"; override val description = "把文字写入当前已聚焦的输入框。参数 text。"
    override fun inputSchema() = schemaOf("text" to "string", required = listOf("text"))
    override fun execute(args: JSONObject): List<McpContent> {
        val t = str(args, "text") ?: return listOf(McpContent.text("错误：缺少 text"))
        return listOf(McpContent.text(DeviceCtrl.typeText(t)))
    }
}

class PhoneKeyTool : McpTool {
    override val isWrite = true
    override val name = "phone_key"; override val description = "执行系统按键：back(返回)/home(主页)/recents(最近任务)/notifications(通知栏)。参数 action。"
    override fun inputSchema() = schemaOf("action" to "string", required = listOf("action"))
    override fun execute(args: JSONObject): List<McpContent> {
        val a = str(args, "action") ?: return listOf(McpContent.text("错误：缺少 action"))
        return listOf(McpContent.text(DeviceCtrl.global(a)))
    }
}

class PhoneOpenAppTool(private val ctx: Context) : McpTool {
    override val isWrite = true
    override val name = "phone_open_app"; override val description = "按应用名称或包名打开手机上的一个 App。参数 target（如“微信”“taobao”）。"
    override fun inputSchema() = schemaOf("target" to "string", required = listOf("target"))
    override fun execute(args: JSONObject): List<McpContent> {
        val target = str(args, "target") ?: return listOf(McpContent.text("错误：缺少 target"))
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(intent, 0)
        val tl = target.lowercase()
        for (ri in list) {
            val pkg = ri.activityInfo.packageName
            val label = try { ri.loadLabel(pm).toString() } catch (e: Exception) { pkg }
            if (label.lowercase().contains(tl) || pkg.lowercase().contains(tl)) {
                val li = pm.getLaunchIntentForPackage(pkg) ?: continue
                li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                return try { ctx.startActivity(li); listOf(McpContent.text("已打开：$label")) } catch (e: Exception) { listOf(McpContent.text("打开失败：" + (e.message ?: ""))) }
            }
        }
        return listOf(McpContent.text("没找到匹配「$target」的 App（可先调 phone_apps 看列表）"))
    }
}

class PhoneAppsTool(private val ctx: Context) : McpTool {
    override val name = "phone_apps"; override val description = "列出手机桌面上一批可启动的应用名称。"
    override fun inputSchema() = schemaOf()
    override fun execute(args: JSONObject): List<McpContent> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(intent, 0)
        val names = sortedSetOf<String>()
        for (ri in list) { try { names.add(ri.loadLabel(pm).toString()) } catch (e: Exception) {} }
        return listOf(McpContent.text(if (names.isEmpty()) "没读到可启动应用" else "手机共 " + names.size + " 个可启动应用：\n" + names.joinToString("、")))
    }
}

class PhoneScreenshotTool : McpTool {
    override val name = "phone_screenshot"; override val description = "读取当前屏幕：返回界面文字元素（含坐标）。【注意：当前版本截图图像不会进入模型上下文，仅下面的文字元素可用；请勿假设你能看到图片。】需先在设置授权屏幕捕获。"
    override fun inputSchema() = schemaOf()
    override fun execute(args: JSONObject): List<McpContent> {
        val dump = DeviceCtrl.dump()
        val bytes = ScreenCaptureService.grab() ?: return listOf(McpContent.text("未授权屏幕捕获（设置→手机控制→授权屏幕捕获）。当前文字元素：\n" + dump))
        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val head = "【注意：图像不会进入模型上下文，仅以下文字元素可用】当前文字元素：\n" + dump
        return listOf(McpContent.text(head), McpContent("image", data = b64, mimeType = "image/jpeg"))
    }
}

/** 注册全部手机控制工具到本地 MCP server。 */
object PhoneControl {
    @Volatile private var registered = false
    fun registerAll(ctx: Context) {
        if (registered) return
        synchronized(this) {
            if (registered) return
            LocalMcpServer.register(EchoTool())
            LocalMcpServer.register(PhoneScreenTool())
            LocalMcpServer.register(PhoneTapTextTool())
            LocalMcpServer.register(PhoneTapTool())
            LocalMcpServer.register(PhoneSwipeTool())
            LocalMcpServer.register(PhoneTypeTool())
            LocalMcpServer.register(PhoneKeyTool())
            LocalMcpServer.register(PhoneOpenAppTool(ctx))
            LocalMcpServer.register(PhoneAppsTool(ctx))
            LocalMcpServer.register(PhoneScreenshotTool())
            registered = true
        }
    }
}
