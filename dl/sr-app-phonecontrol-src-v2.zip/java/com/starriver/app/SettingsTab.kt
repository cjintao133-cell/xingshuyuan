package com.starriver.app

/*
 * SettingsTab.kt（重写）
 * 变更：
 *  1) 端点区只留 base / API Key / 模型 id；人设 system 输入框已移除（保存时原样透传 config.system）。
 *  2) 校验端点 / 拉取模型：点击即禁用并显示进行中；结果在顶部固定状态区 + Toast；模型列表渲染为可点胶囊。
 *  3) 失败原因红字加粗，并提示 base 与 key 需属于同一家服务商。
 *  4) 去除全部 emoji，改为本文件内 Canvas 线性图标（StIcon，可迁入 AppIcons.kt）。
 *  5) 三层结构与 Permission/Report/Safety/Panels/Diag 子屏调用保持不变。
 *
 * i18n：文案一律经 tr(key, fallback) → AppI18n.t(key)。
 *  下方每个 tr("settings.x.*", "...") 的 key 都是待补到 kernel/i18n zh.json / en.json 的新 key，
 *  第二个参数即 zh 值；en 值需另补。真源补齐后可删除 fallback。
 */

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import mobilebind.Mobilebind
import org.json.JSONArray
import org.json.JSONObject

/* ───────────────────────── Canvas 线性图标 ───────────────────────── */

private enum class StGlyph { CHECK, CROSS, SHIELD, CHART, PULSE, CHEVRON, LOCK, FLAG }

@Composable
private fun StIcon(
    glyph: StGlyph,
    modifier: Modifier = Modifier.size(20.dp),
    tint: Color = MaterialTheme.colorScheme.onSurfaceVariant,
) {
    Canvas(modifier) {
        val w = size.minDimension
        val st = Stroke(width = w * 0.085f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun line(x1: Float, y1: Float, x2: Float, y2: Float) {
            drawLine(tint, Offset(x1 * w, y1 * w), Offset(x2 * w, y2 * w), strokeWidth = st.width, cap = StrokeCap.Round)
        }
        fun poly(close: Boolean, vararg p: Float) {
            val path = Path()
            path.moveTo(p[0] * w, p[1] * w)
            var i = 2
            while (i + 1 < p.size) {
                path.lineTo(p[i] * w, p[i + 1] * w)
                i += 2
            }
            if (close) path.close()
            drawPath(path = path, color = tint, style = st)
        }
        when (glyph) {
            StGlyph.CHECK -> poly(false, 0.18f, 0.52f, 0.42f, 0.74f, 0.82f, 0.28f)
            StGlyph.CROSS -> {
                line(0.24f, 0.24f, 0.76f, 0.76f)
                line(0.76f, 0.24f, 0.24f, 0.76f)
            }
            StGlyph.SHIELD -> {
                poly(true, 0.5f, 0.1f, 0.84f, 0.24f, 0.84f, 0.5f, 0.74f, 0.72f, 0.5f, 0.9f, 0.26f, 0.72f, 0.16f, 0.5f, 0.16f, 0.24f)
                poly(false, 0.36f, 0.5f, 0.47f, 0.61f, 0.66f, 0.4f)
            }
            StGlyph.CHART -> {
                line(0.14f, 0.86f, 0.86f, 0.86f)
                line(0.28f, 0.7f, 0.28f, 0.54f)
                line(0.5f, 0.7f, 0.5f, 0.2f)
                line(0.72f, 0.7f, 0.72f, 0.4f)
            }
            StGlyph.PULSE -> poly(false, 0.08f, 0.55f, 0.3f, 0.55f, 0.4f, 0.25f, 0.54f, 0.8f, 0.64f, 0.55f, 0.92f, 0.55f)
            StGlyph.CHEVRON -> poly(false, 0.38f, 0.22f, 0.66f, 0.5f, 0.38f, 0.78f)
            StGlyph.LOCK -> {
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(0.2f * w, 0.46f * w),
                    size = Size(0.6f * w, 0.42f * w),
                    cornerRadius = CornerRadius(0.08f * w, 0.08f * w),
                    style = st,
                )
                drawArc(
                    color = tint,
                    startAngle = 180f,
                    sweepAngle = 180f,
                    useCenter = false,
                    topLeft = Offset(0.32f * w, 0.12f * w),
                    size = Size(0.36f * w, 0.68f * w),
                    style = st,
                )
            }
            StGlyph.FLAG -> {
                line(0.24f, 0.12f, 0.24f, 0.9f)
                poly(false, 0.24f, 0.16f, 0.8f, 0.16f, 0.66f, 0.34f, 0.8f, 0.52f, 0.24f, 0.52f)
            }
        }
    }
}

/* ───────────────────────── 通用小组件 ───────────────────────── */

@Composable
private fun SectionTitle(text: String) {
    Row(
        Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(3.dp).height(15.dp).clip(RoundedCornerShape(2.dp)).background(MaterialTheme.colorScheme.primary))
        Spacer(Modifier.width(8.dp))
        Text(text, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun Hint(text: String) {
    Text(text, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun ChoiceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(LocalCornerRadius.current)
    Box(
        Modifier
            .clip(shape)
            .background(if (selected) cs.primaryContainer else cs.surface)
            .border(1.dp, if (selected) cs.primary else cs.outline, shape)
            .clickable(onClick = onClick)
            .defaultMinSize(minHeight = 38.dp)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            fontSize = 13.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) cs.onPrimaryContainer else cs.onSurface,
        )
    }
}

@Composable
private fun Field(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
    secret: Boolean = false,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        modifier = modifier,
        singleLine = true,
        shape = RoundedCornerShape(LocalCornerRadius.current),
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
    )
}

@Composable
private fun SwitchRow(title: String, sub: String?, checked: Boolean, strong: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(
                title,
                fontSize = if (strong) 15.sp else 13.sp,
                fontWeight = if (strong) FontWeight.Bold else FontWeight.Normal,
                color = MaterialTheme.colorScheme.onSurface,
            )
            if (!sub.isNullOrEmpty()) Hint(sub)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** 带进行中态的按钮：busy 时禁用并显示转圈 + 进行中文案。 */
@Composable
private fun ActionButton(
    label: String,
    busyLabel: String,
    busy: Boolean,
    enabled: Boolean,
    primary: Boolean = false,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(LocalCornerRadius.current)
    val content: @Composable () -> Unit = {
        if (busy) {
            CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
            Spacer(Modifier.width(6.dp))
        }
        Text(if (busy) busyLabel else label, maxLines = 1)
    }
    if (primary) {
        Button(onClick = onClick, enabled = enabled && !busy, shape = shape, modifier = modifier) { content() }
    } else {
        OutlinedButton(onClick = onClick, enabled = enabled && !busy, shape = shape, modifier = modifier) { content() }
    }
}

@Composable
private fun NavRow(glyph: StGlyph, label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(LocalCornerRadius.current)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(cs.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        StIcon(glyph, Modifier.size(22.dp), cs.primary)
        Text(label, modifier = Modifier.weight(1f), fontSize = 14.sp, color = cs.onSurface)
        StIcon(StGlyph.CHEVRON, Modifier.size(16.dp), cs.onSurfaceVariant)
    }
}

/** 固定状态区：空闲提示 / 进行中 / 成功 / 失败（红字 + 同一家提示）。kind: 0 无 1 成功 2 失败 */
@Composable
private fun StatusBanner(busy: Boolean, kind: Int, title: String, detail: String, idleText: String, failHint: String) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(LocalCornerRadius.current)
    val failed = !busy && kind == 2
    val ok = !busy && kind == 1
    val bg = if (ok) cs.primaryContainer else if (failed) cs.surface else cs.surfaceVariant
    val fg = if (ok) cs.onPrimaryContainer else if (failed) cs.error else cs.onSurfaceVariant
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(bg)
            .then(if (failed) Modifier.border(2.dp, cs.error, shape) else Modifier)
            .padding(12.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        when {
            busy -> CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
            ok -> StIcon(StGlyph.CHECK, Modifier.size(20.dp), fg)
            failed -> StIcon(StGlyph.CROSS, Modifier.size(20.dp), fg)
            else -> StIcon(StGlyph.PULSE, Modifier.size(20.dp), fg)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                if (!busy && kind == 0) idleText else title,
                fontSize = if (failed) 15.sp else 13.sp,
                fontWeight = if (ok || failed) FontWeight.Bold else FontWeight.Normal,
                color = fg,
            )
            if (!busy && detail.isNotEmpty()) {
                Text(detail, fontSize = 12.sp, color = fg, maxLines = 5, overflow = TextOverflow.Ellipsis)
            }
            if (failed) {
                Text(failHint, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = cs.error)
            }
        }
    }
}

private fun parseModelIds(raw: String): List<String>? = try {
    val t = raw.trim()
    val arr = if (t.startsWith("[")) JSONArray(t) else (JSONObject(t).optJSONArray("data") ?: JSONArray())
    val out = ArrayList<String>()
    for (i in 0 until arr.length()) {
        val id = arr.optJSONObject(i)?.optString("id") ?: arr.optString(i)
        if (!id.isNullOrBlank()) out.add(id)
    }
    out.distinct()
} catch (e: Exception) {
    null
}

/* ───────────────────────── 设置主屏 ───────────────────────── */

/**
 * 设置主屏：不再分「新手/进阶/开发者」三层，改成按「用途」分组的一页式索引。
 * 每行是「标题 + 一句人话」；点进各自子屏。语言常驻顶部；外观/模型/网络/备份等收进子屏。
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsTab(
    config: ChatConfig,
    theme: ThemeConfig,
    reduceMotion: Boolean,
    lang: String,
    followSystem: Boolean,
    onThemeChange: (ThemeConfig) -> Unit,
    onReduceMotionChange: (Boolean) -> Unit,
    onLangChange: (String) -> Unit,
    onFollowSystem: () -> Unit,
    onSave: (ChatConfig) -> Unit,
    fontScale: Float,
    onFontScaleChange: (Float) -> Unit,
) {
    var screen by remember { mutableStateOf(0) }
    BackHandler(enabled = screen != 0) { screen = 0 }
    if (screen == 1) { PermissionScreen { screen = 0 }; return }
    if (screen == 2) { ReportScreen { screen = 0 }; return }
    if (screen == 3) { SafetyScreen { screen = 0 }; return }
    if (screen == 4) { PanelsScreen { screen = 0 }; return }
    if (screen == 5) { DiagScreen { screen = 0 }; return }
    if (screen == 6) { FilesScreen { screen = 0 }; return }
    if (screen == 7) { McpScreen { screen = 0 }; return }
    if (screen == 8) { AdvancedScreen { screen = 0 }; return }
    if (screen == 9) { FeatureSettingsScreen { screen = 0 }; return }
    if (screen == 10) { RegexSettingsScreen { screen = 0 }; return }
    if (screen == 11) { MemoryScreen { screen = 0 }; return }
    if (screen == 12) { AboutScreen { screen = 0 }; return }
    if (screen == 13) { CapabilityScreen { screen = 0 }; return }
    if (screen == 14) { KernelToolsScreen(config) { screen = 0 }; return }
    if (screen == 15) { ScreenShell(l10n("模型与端点", "Models & endpoints"), onClose = { screen = 0 }) { NoviceSettings(config, onSave) }; return }
    if (screen == 16) { ScreenShell(l10n("外观 · 画图 · 网络 · 备份", "Appearance · image · network · backup"), onClose = { screen = 0 }) { AdvancedSettings(theme, reduceMotion, onThemeChange, onReduceMotionChange, fontScale, onFontScaleChange) }; return }
    if (screen == 17) { PhoneControlScreen { screen = 0 }; return }

    SettingsHome(
        config = config,
        lang = lang,
        followSystem = followSystem,
        onLangChange = onLangChange,
        onFollowSystem = onFollowSystem,
        onOpen = { screen = it },
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SettingsHome(
    config: ChatConfig,
    lang: String,
    followSystem: Boolean,
    onLangChange: (String) -> Unit,
    onFollowSystem: () -> Unit,
    onOpen: (Int) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().background(cs.background).padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(AppI18n.t("settings.title"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = cs.onBackground)
        Text(
            l10n("开关都在这儿，按用途分组；不确定就先保持默认。", "Everything's here, grouped by purpose. When unsure, keep the defaults."),
            fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp, bottom = 6.dp),
        )
        Text(AppI18n.t("settings.language"), fontSize = 12.sp, color = cs.onSurfaceVariant)
        Spacer(Modifier.height(4.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ChoiceChip(tr("settings.x.lang_follow", "跟随系统"), followSystem) { onFollowSystem() }
            ChoiceChip("中文", !followSystem && lang == "zh") { onLangChange("zh") }
            ChoiceChip("English", !followSystem && lang == "en") { onLangChange("en") }
        }
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            DomainHeader(l10n("常用", "Essentials"), l10n("刚开始只需要这两项", "Just these two to get going"))
            NavCard(StGlyph.FLAG, l10n("模型与端点", "Models & endpoints"), endpointSub(config)) { onOpen(15) }
            NavCard(StGlyph.CHART, l10n("能力总览", "Capabilities"), l10n("145 项内核能力：哪些已接入、哪些没入口，一眼看清", "All 145 kernel APIs: what's wired, what isn't")) { onOpen(13) }

            DomainHeader(l10n("对话与内容", "Chat & content"), l10n("语音、表情、格式化与文件", "Voice, expressions, formatting, files"))
            NavCard(StGlyph.CHECK, l10n("功能与开关", "Features"), l10n("语音朗读 / 听写、表情、知识库总开关", "TTS/STT, expressions, knowledge base")) { onOpen(9) }
            NavCard(StGlyph.CHART, l10n("正则与格式化", "Regex & formatting"), l10n("用规则自动替换 / 整理消息文本", "Auto-rewrite message text by rules")) { onOpen(10) }
            NavCard(StGlyph.FLAG, l10n("文件与知识库", "Files & knowledge"), l10n("导入文件、本地检索、分享与删除", "Import, local search, share, delete")) { onOpen(6) }

            DomainHeader(l10n("记忆", "Memory"), l10n("它记住你的偏好与事实", "She remembers your preferences & facts"))
            NavCard(StGlyph.PULSE, l10n("记忆管理", "Memory"), l10n("长期偏好与事实、导入导出、清理", "Long-term facts, import/export, clear")) { onOpen(11) }

            DomainHeader(l10n("外观与高级", "Appearance & advanced"), l10n("主题、字体、画图、网络与备份", "Theme, font, image, network, backup"))
            NavCard(StGlyph.PULSE, l10n("外观 · 画图 · 网络 · 备份", "Appearance · image · network · backup"), l10n("主题字体、画图 / 向量 / 灾备端点、代理、加密备份、主动消息", "Theme/font, image/embed/backup endpoints, proxy, encrypted backup, proactive")) { onOpen(16) }

            DomainHeader(l10n("扩展与插件", "Extensions"), l10n("接入外部工具与服务器", "Plug in external tools & servers"))
            NavCard(StGlyph.SHIELD, l10n("MCP 生态", "MCP ecosystem"), l10n("装 / 管外部工具服务器，按需启用", "Install/manage external tool servers")) { onOpen(7) }
            NavCard(StGlyph.PULSE, l10n("手机控制", "Phone control"), l10n("让 AI 读屏、点击、输入、滑动、开 App（授权无障碍/屏幕）", "Let AI read screen, tap, type, swipe, open apps")) { onOpen(17) }

            DomainHeader(l10n("隐私 · 安全 · 预算", "Privacy · safety · budget"), l10n("谁能做什么、花多少、要不要先问你", "Who can do what, spend limits, confirmations"))
            NavCard(StGlyph.LOCK, l10n("权限管理", "Permissions"), l10n("授权 / 回收各类系统与应用权限", "Grant/revoke system & app permissions")) { onOpen(1) }
            NavCard(StGlyph.SHIELD, l10n("安全与自愈", "Safety & self-heal"), l10n("注入防护、异常检测、看门狗自愈", "Injection defense, anomaly detection, watchdog")) { onOpen(3) }
            NavCard(StGlyph.FLAG, l10n("举报与反馈", "Report & feedback"), l10n("上报问题、查看合规策略", "Report issues, view compliance policy")) { onOpen(2) }

            DomainHeader(l10n("能力与诊断", "Tools & diagnostics"), l10n("进阶工具，平时用不到", "Advanced tools, rarely needed"))
            NavCard(StGlyph.PULSE, l10n("内核工具", "Kernel tools"), l10n("策略试跑、钩子、追踪、记忆卫生、定时下次触发", "Policy dry-run, hooks, tracing, hygiene, cron next")) { onOpen(14) }
            NavCard(StGlyph.CHART, l10n("内核控制台", "Kernel console"), l10n("任务 / 技能 / 连接器 / 身份 / 产物等完整面板", "Tasks/skills/connectors/identity/artifacts panels")) { onOpen(8) }
            NavCard(StGlyph.PULSE, l10n("崩溃诊断 · 隐私边界", "Crash diag · privacy boundary"), l10n("看崩溃转储、确认哪些数据不出设备", "Crash dumps; confirm what never leaves device")) { onOpen(5) }
            NavCard(StGlyph.CHECK, l10n("重新查看使用引导", "Replay onboarding"), l10n("下次启动时再走一遍新手引导", "Show the intro again on next launch")) {
                Onboarding.reset(AppCtx.ctx)
                Toast.makeText(AppCtx.ctx, l10n("下次启动显示引导", "Intro shown on next launch"), Toast.LENGTH_SHORT).show()
            }
            NavCard(StGlyph.SHIELD, l10n("关于 / 版本", "About / version"), l10n("版本号、许可、开源地址", "Version, license, repo")) { onOpen(12) }
            Spacer(Modifier.height(22.dp))
        }
    }
}

private fun endpointSub(config: ChatConfig): String =
    if (config.baseUrl.isBlank() || config.model.isBlank())
        l10n("还没配置：填地址 / 密钥 / 选模型，才能开始对话", "Not set yet: fill endpoint / key / model to start chatting")
    else
        l10n("已连接：", "Connected: ") + config.model

@Composable
private fun DomainHeader(title: String, sub: String) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().padding(top = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(3.dp).height(14.dp).clip(RoundedCornerShape(2.dp)).background(cs.primary))
            Spacer(Modifier.width(8.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = cs.onSurface)
        }
        if (sub.isNotEmpty()) Text(sub, fontSize = 11.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 11.dp, top = 2.dp))
    }
}

@Composable
private fun NavCard(glyph: StGlyph, title: String, sub: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(LocalCornerRadius.current)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(cs.surfaceVariant).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        StIcon(glyph, Modifier.size(22.dp), cs.primary)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = cs.onSurface)
            if (sub.isNotEmpty()) Text(sub, fontSize = 11.sp, color = cs.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        StIcon(StGlyph.CHEVRON, Modifier.size(16.dp), cs.onSurfaceVariant)
    }
}

@Composable
private fun ScreenShell(title: String, onClose: () -> Unit, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().background(cs.background)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 6.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).clickable { onClose() }, contentAlignment = Alignment.Center) {
                IconBack(cs.onSurface)
            }
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, modifier = Modifier.padding(start = 4.dp))
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) { content() }
    }
}

/* ───────────────────────── 新手：端点 / Key / 模型 ───────────────────────── */

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun NoviceSettings(config: ChatConfig, onSave: (ChatConfig) -> Unit) {
    val ctx = LocalContext.current
    var base by remember { mutableStateOf(config.baseUrl) }
    var key by remember { mutableStateOf(config.apiKey) }
    var model by remember { mutableStateOf(config.model) }
    var busy by remember { mutableStateOf(0) }      // 0 空闲 1 校验中 2 拉模型中
    var kind by remember { mutableStateOf(0) }      // 0 无 1 成功 2 失败
    var title by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("") }
    val models = remember { mutableStateListOf<String>() }

    val sIdle = tr("settings.x.endpoint_idle", "填好端点与 Key 后，可先校验端点或拉取模型列表；结果显示在这里。")
    val sProbing = tr("settings.x.probing", "校验中…")
    val sProbe = tr("settings.x.probe", "校验端点")
    val sProbeOk = tr("settings.x.probe_ok", "端点可用")
    val sProbeFail = tr("settings.x.probe_fail", "校验失败")
    val sListing = tr("settings.x.listing", "拉取中…")
    val sList = tr("settings.x.list_models", "拉取模型")
    val sListOk = tr("settings.x.list_ok", "已拉取模型，点选下方胶囊填入")
    val sListFail = tr("settings.x.list_fail", "拉取模型失败")
    val sListEmpty = tr("settings.x.list_empty", "端点未返回任何模型")
    val sFailHint = tr("settings.x.same_vendor_hint", "请确认端点 base 与 API Key 属于同一家服务商。")
    val sSaved = tr("settings.x.saved", "已保存")
    val sModelLabel = AppI18n.t("settings.model")
    val errLabels = mapOf(
        "network" to AppI18n.t("error.network"),
        "timeout" to AppI18n.t("error.timeout"),
        "auth" to AppI18n.t("error.auth"),
        "rate_limit" to AppI18n.t("error.rate_limit"),
        "server" to AppI18n.t("error.server"),
        "protocol" to AppI18n.t("error.protocol"),
    )

    fun toast(msg: String) {
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    }

    fun probe() {
        if (busy != 0) return
        val b = base.trim(); val k = key.trim(); val m = model.trim()
        busy = 1; kind = 0; title = sProbing; detail = ""
        Bg.run({ Mobilebind.probeEndpoint(b, k, m) }) { raw ->
            busy = 0
            try {
                val o = JSONObject(raw)
                if (o.optBoolean("ok")) {
                    kind = 1; title = sProbeOk
                    detail = sModelLabel + " " + o.optString("model").ifBlank { m }
                } else {
                    val cat = o.optString("category")
                    val err = o.optString("error")
                    kind = 2; title = sProbeFail
                    detail = listOf(errLabels[cat] ?: cat, err).filter { it.isNotBlank() }.joinToString("\n")
                }
            } catch (e: Exception) {
                kind = 2; title = sProbeFail; detail = raw.removePrefix("ERR:")
            }
            toast(title)
        }
    }

    fun listModels() {
        if (busy != 0) return
        val b = base.trim(); val k = key.trim()
        busy = 2; kind = 0; title = sListing; detail = ""
        Bg.run({ Mobilebind.listModels(b, k) }) { raw ->
            busy = 0
            val ids = if (raw.startsWith("ERR:")) null else parseModelIds(raw)
            if (ids == null) {
                kind = 2; title = sListFail; detail = raw.removePrefix("ERR:")
            } else if (ids.isEmpty()) {
                kind = 2; title = sListEmpty; detail = ""
            } else {
                models.clear(); models.addAll(ids); filter = ""
                kind = 1; title = sListOk; detail = "× " + ids.size
            }
            toast(title)
        }
    }

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // 固定状态区：不随滚动，永远在按钮上方，不被底部导航/键盘遮挡
        StatusBanner(busy != 0, kind, title, detail, sIdle, sFailHint)

        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Hint(tr("settings.x.endpoint_hint", "端点、Key、模型均由你自行填写；Key 经 Android Keystore 加密，不落明文。"))
            Field(base, { base = it }, AppI18n.t("settings.endpoint"))
            Field(key, { key = it }, AppI18n.t("settings.apikey"), secret = true)
            Field(model, { model = it }, sModelLabel)

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                ActionButton(
                    label = AppI18n.t("common.save"),
                    busyLabel = AppI18n.t("common.save"),
                    busy = false,
                    enabled = base.isNotBlank() && key.isNotBlank() && model.isNotBlank(),
                    primary = true,
                ) {
                    // 人设不属于端点页：system 原样透传，不在此编辑
                    onSave(ChatConfig(base.trim(), key.trim(), model.trim(), config.system))
                    toast(sSaved)
                }
                ActionButton(
                    label = sProbe,
                    busyLabel = sProbing,
                    busy = busy == 1,
                    enabled = busy == 0 && base.isNotBlank() && model.isNotBlank(),
                ) { probe() }
                ActionButton(
                    label = sList,
                    busyLabel = sListing,
                    busy = busy == 2,
                    enabled = busy == 0 && base.isNotBlank(),
                ) { listModels() }
            }

            if (models.isNotEmpty()) {
                SectionTitle(tr("settings.x.models_title", "可用模型（点选填入）") + " · " + models.size)
                if (models.size > 12) {
                    Field(filter, { filter = it }, tr("settings.x.models_filter", "筛选模型"))
                }
                val q = filter.trim()
                val shown = if (q.isEmpty()) models.toList() else models.filter { it.contains(q, ignoreCase = true) }
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    shown.forEach { id ->
                        ChoiceChip(id, id == model.trim()) { model = id }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

/* ───────────────────── 外观 · 高级配置 ───────────────────── */

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AdvancedSettings(
    theme: ThemeConfig,
    reduceMotion: Boolean,
    onThemeChange: (ThemeConfig) -> Unit,
    onReduceMotionChange: (Boolean) -> Unit,
    fontScale: Float,
    onFontScaleChange: (Float) -> Unit,
    onOpenPanels: () -> Unit = {},
    onOpenDiag: () -> Unit = {},
    onOpenFiles: () -> Unit = {},
    onOpenMcp: () -> Unit = {},
    onOpenFeatures: () -> Unit = {},
    onOpenRegex: () -> Unit = {},
    onOpenAdvanced: () -> Unit = {},
    onOpenMemory: () -> Unit = {},
) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var personalTag by remember { mutableStateOf(SysPrefs.personalTag(ctx)) }
    var imgBase by remember { mutableStateOf(ImagePrefs.base(ctx)) }
    var imgModel by remember { mutableStateOf(ImagePrefs.model(ctx)) }
    var imgKey by remember { mutableStateOf(ImagePrefs.apiKey(ctx)) }
    var imgEditPath by remember { mutableStateOf(ImagePrefs.editPath(ctx)) }
    var embBase by remember { mutableStateOf(EmbedPrefs.base(ctx)) }
    var embModel by remember { mutableStateOf(EmbedPrefs.model(ctx)) }
    var embKey by remember { mutableStateOf(EmbedPrefs.key(ctx)) }
    var bkBase by remember { mutableStateOf(BackupPrefs.base(ctx)) }
    var bkModel by remember { mutableStateOf(BackupPrefs.model(ctx)) }
    var bkKey by remember { mutableStateOf(BackupPrefs.key(ctx)) }
    var bkProvider by remember { mutableStateOf(BackupPrefs.provider(ctx)) }
    var chatProto by remember { mutableStateOf(ProtoPrefs.provider(ctx)) }
    var proxyUrl by remember { mutableStateOf(ProxyPrefs.url(ctx)) }
    var summaryOn by remember { mutableStateOf(Prefs.summaryEnabled(ctx)) }
    var summaryTh by remember { mutableStateOf(Prefs.summaryThreshold(ctx).toString()) }
    var exprOn by remember { mutableStateOf(Prefs.exprEnabled(ctx)) }
    var proxyNow by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { Bg.run({ Mobilebind.getNetworkProxy() }) { proxyNow = if (it.isEmpty()) Loc.t("（直连）") else it } }
    var proStatus by remember { mutableStateOf(ProactiveUi.status()) }
    var backupNote by remember { mutableStateOf("") }
    var backupPwd by remember { mutableStateOf("") }
    var backupFailed by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf("") }
    var savedFailed by remember { mutableStateOf(false) }

    val sExportEmpty = tr("settings.x.backup_export_empty", "导出为空")
    val sWrongPwd = tr("settings.x.backup_wrong_pwd", "密码错误或文件损坏")
    val sReadFail = tr("settings.x.backup_read_fail", "读取失败")
    val sExported = tr("settings.x.backup_exported", "已导出备份")
    val sImported = tr("settings.x.backup_imported", "已导入备份（重启 App 生效更稳妥）")
    val sTicked = tr("settings.x.proactive_ticked", "已触发一次主动评估")
    val sSavedImgMissing = tr("settings.x.adv_saved_img_missing", "已保存（画图模型未配全）")
    val sSavedImgFail = tr("settings.x.adv_saved_img_fail", "已保存，画图初始化失败：")
    val sSavedImgReady = tr("settings.x.adv_saved_img_ready", "已保存，画图模型就绪")
    val sProtoOpenAi = tr("settings.x.proto_openai", "OpenAI 兼容")

    fun toast(msg: String) {
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) Bg.run({
            val data = FullBackup.export(ctx)
            if (data == null || data.isEmpty()) return@run "ERR:$sExportEmpty"
            try {
                val pwd0 = backupPwd.trim()
                val out = if (pwd0.isNotEmpty()) BackupCrypto.encrypt(data, pwd0) else data
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(out) }; "OK"
            } catch (e: Exception) {
                "ERR:" + (e.message ?: "?")
            }
        }) { r ->
            backupFailed = r != "OK"
            backupNote = if (r == "OK") sExported else r.removePrefix("ERR:")
            toast(backupNote)
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) Bg.run({
            val data = try {
                ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            } catch (e: Exception) {
                null
            }
            if (data == null) return@run "ERR:$sReadFail"
            val dec = BackupCrypto.decrypt(data, backupPwd.trim())
            if (dec == null) return@run "ERR:$sWrongPwd"
            FullBackup.import(ctx, dec)
        }) { r ->
            backupFailed = !r.startsWith("OK:")
            backupNote = if (r.startsWith("OK:")) sImported else r.removePrefix("ERR:")
            toast(backupNote)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        // （工具入口已上移到设置主页；此处保留高级配置表单）

        // 聊天协议
        SectionTitle(tr("settings.x.proto_title", "聊天协议（模型厂商）"))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ChoiceChip(sProtoOpenAi, chatProto == "openai") { chatProto = "openai" }
            ChoiceChip("Claude", chatProto == "anthropic") { chatProto = "anthropic" }
            ChoiceChip("Gemini", chatProto == "gemini") { chatProto = "gemini" }
        }
        Hint(tr("settings.x.proto_hint", "选 Claude/Gemini 时，端点/模型按对应官方或中转地址填。"))

        // 主动消息
        SectionTitle(AppI18n.t("proactive.title"))
        SwitchRow(
            tr("settings.x.proactive_enable", "启用主动消息"),
            tr("settings.x.proactive_enable_hint", "可随时撤回的权限，默认关闭"),
            proStatus.enabled, strong = false,
        ) { v -> Bg.run({ Mobilebind.proactiveSetEnabled(v); "OK" }) { proStatus = ProactiveUi.status() } }
        if (proStatus.enabled) {
            SwitchRow(tr("settings.x.proactive_mem", "记忆复习到期"), null, proStatus.memReview, strong = false) { v ->
                Bg.run({ Mobilebind.proactiveSetSource("memory_review", v); "OK" }) { proStatus = ProactiveUi.status() }
            }
            SwitchRow(tr("settings.x.proactive_schedule", "人设日程"), null, proStatus.schedule, strong = false) { v ->
                Bg.run({ Mobilebind.proactiveSetSource("schedule", v); "OK" }) { proStatus = ProactiveUi.status() }
            }
            SwitchRow(tr("settings.x.proactive_emotion", "情绪驱动"), null, proStatus.emotion, strong = false) { v ->
                Bg.run({ Mobilebind.proactiveSetSource("emotion", v); "OK" }) { proStatus = ProactiveUi.status() }
            }
            OutlinedButton(
                onClick = { Bg.run({ ProactiveUi.tickAndNotify(ctx).toString() }) { toast(sTicked) } },
                shape = RoundedCornerShape(LocalCornerRadius.current),
            ) { Text(tr("settings.x.proactive_tick", "立即评估一次")) }
        }

        // 主题
        SectionTitle(AppI18n.t("settings.theme"))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ChoiceChip(tr("settings.x.theme_day", "卡其日间"), theme.mode == ThemeMode.DAY) {
                onThemeChange(theme.copy(mode = ThemeMode.DAY))
            }
            ChoiceChip(tr("settings.x.theme_night", "夜间流星"), theme.mode == ThemeMode.NIGHT) {
                onThemeChange(theme.copy(mode = ThemeMode.NIGHT))
            }
        }
        Hint(tr("settings.x.accent", "自定义强调色"))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            AccentPresets.forEach { (argb, _) ->
                val c = if (argb == null) cs.primary else Color(argb)
                val selected = theme.accent == argb
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(c, CircleShape)
                        .border(if (selected) 3.dp else 1.dp, if (selected) cs.onSurface else cs.outline, CircleShape)
                        .clickable { onThemeChange(theme.copy(accent = argb)) },
                    contentAlignment = Alignment.Center,
                ) {
                    if (selected) StIcon(StGlyph.CHECK, Modifier.size(16.dp), cs.onPrimary)
                }
            }
        }
        Hint(tr("settings.x.radius", "圆角档"))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            RadiusPresets.forEach { (dpv, name) ->
                val nm = when (dpv) { 8 -> tr("radius.compact", name); 16 -> tr("radius.normal", name); 24 -> tr("radius.loose", name); else -> name }
                ChoiceChip(nm, theme.radiusDp == dpv) { onThemeChange(theme.copy(radiusDp = dpv)) }
            }
        }
        Hint(tr("settings.x.font_size", "字体大小"))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            val fontOpts = listOf(0.9f to tr("font.small", "小"), 1.0f to tr("font.normal", "标准"), 1.15f to tr("font.large", "大"), 1.3f to tr("font.xlarge", "特大"))
            fontOpts.forEach { (fv, fn) ->
                ChoiceChip(fn, kotlin.math.abs(fontScale - fv) < 0.01f) { onFontScaleChange(fv) }
            }
        }

        SwitchRow(
            tr("settings.x.reduce_motion", "减少动态 / 关闭氛围动效"),
            tr("settings.x.reduce_motion_hint", "夜间流星背景静止为静态星空（省电、无障碍）"),
            reduceMotion, strong = true, onChange = onReduceMotionChange,
        )

        // 画图
        SectionTitle(tr("settings.x.img_title", "画图模型（相册/自拍：人设图垫图）"))
        Field(imgBase, { imgBase = it }, tr("settings.x.img_base", "画图端点 base"))
        Field(imgModel, { imgModel = it }, tr("settings.x.img_model", "画图模型 id（需支持图生图）"))
        Field(imgKey, { imgKey = it }, tr("settings.x.img_key", "画图 API Key（加密存储）"), secret = true)
        Field(imgEditPath, { imgEditPath = it }, tr("settings.x.img_edit_path", "图生图路径（默认 /images/edits，可留空）"))
        Hint(tr("settings.x.img_hint", "垫图=人设图；有垫图走图生图端点保角色一致性。生成图片强制带 AI 水印。"))

        // embedding
        SectionTitle(tr("settings.x.emb_title", "语义记忆（embedding，可选）"))
        Hint(tr("settings.x.emb_hint", "配了才有向量召回，否则走关键词。"))
        Field(embBase, { embBase = it }, tr("settings.x.emb_base", "embedding 端点 base（可同聊天端点）"))
        Field(embModel, { embModel = it }, tr("settings.x.emb_model", "embedding 模型 id"))
        Field(embKey, { embKey = it }, tr("settings.x.emb_key", "embedding API Key（加密存储）"), secret = true)

        // 灾备
        SectionTitle(tr("settings.x.bk_title", "灾备备用端点（可选：主端点失败自动切）"))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("openai" to sProtoOpenAi, "anthropic" to "Claude", "gemini" to "Gemini").forEach { (k, label) ->
                ChoiceChip(label, bkProvider == k) { bkProvider = k }
            }
        }
        Field(bkBase, { bkBase = it }, tr("settings.x.bk_base", "备用端点 base（留空=不使用灾备）"))
        Field(bkModel, { bkModel = it }, tr("settings.x.bk_model", "备用模型 id"))
        Field(bkKey, { bkKey = it }, tr("settings.x.bk_key", "备用 API Key（加密存储）"), secret = true)

        // 数据备份
        SectionTitle(tr("settings.x.backup_title", "数据备份（换机/防丢）"))
        if (backupNote.isNotEmpty()) {
            Text(
                backupNote,
                fontSize = 12.sp,
                fontWeight = if (backupFailed) FontWeight.Bold else FontWeight.Normal,
                color = if (backupFailed) cs.error else cs.primary,
            )
        }
        Field(backupPwd, { backupPwd = it }, tr("settings.x.backup_pwd", "备份密码（可选：加密后更安全，换机导入需同密码）"), secret = true)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            OutlinedButton(
                onClick = { exportLauncher.launch("star-river-backup.zip") },
                shape = RoundedCornerShape(LocalCornerRadius.current),
            ) { Text(tr("settings.x.backup_export", "导出备份")) }
            OutlinedButton(
                onClick = { importLauncher.launch("application/zip") },
                shape = RoundedCornerShape(LocalCornerRadius.current),
            ) { Text(tr("settings.x.backup_import", "导入备份")) }
        }

        // 网络与标识（代理 + 应用标识请求头）
        SectionTitle(tr("settings.x.net_title", "网络与标识"))
        OutlinedTextField(
            value = proxyUrl, onValueChange = { proxyUrl = it },
            label = { Text(tr("settings.x.proxy_label", "HTTP/SOCKS 代理（留空=直连）")) },
            placeholder = { Text("http://127.0.0.1:7890") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Hint(tr("settings.x.proxy_hint", "生效于模型对话/搜索/语音/绘画/MCP；保存后立即应用。例：http://127.0.0.1:7890 或 socks5://127.0.0.1:1080"))
        Text(tr("settings.x.proxy_now", "当前内核代理：") + proxyNow, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        Field(personalTag, { personalTag = it }, tr("settings.x.tag_label", "X-Star-River-Tag（可选）"))
        Hint(tr("settings.x.tag_hint2", "每个发往你自配端点的请求都会带一个轻量标识头（默认 X-Star-River-Client，此处可加自己的 X-Star-River-Tag）。多数中转/服务商控制台可见，便于区分流量与排查，不影响对话内容。"))

        // 智能增强
        SectionTitle(tr("settings.x.smart_title", "智能增强"))
        SwitchRow(tr("settings.x.summary_on", "自动摘要滚动记忆"), tr("settings.x.summary_on_hint", "长对话自动把旧对话压成摘要，缓解记忆丢失（走你的模型，会少量耗 token）"), summaryOn, strong = false) { v ->
            summaryOn = v; Prefs.setSummaryEnabled(ctx, v)
        }
        if (summaryOn) {
            OutlinedTextField(
                value = summaryTh, onValueChange = { v ->
                    if (v.length <= 3 && v.all { it.isDigit() }) { summaryTh = v; v.toIntOrNull()?.let { Prefs.setSummaryThreshold(ctx, it) } }
                },
                label = { Text(tr("settings.x.summary_th", "摘要触发条数（默认 40）")) }, singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        SwitchRow(tr("settings.x.expr_on", "角色表情立绘"), tr("settings.x.expr_on_hint", "按情绪自动切换立绘（需在联系人编辑里为角色上传立绘）"), exprOn, strong = false) { v ->
            exprOn = v; Prefs.setExprEnabled(ctx, v)
        }

        // 保存：结果在按钮上方 + Toast
        if (saved.isNotEmpty()) {
            Text(
                saved,
                fontSize = 12.sp,
                fontWeight = if (savedFailed) FontWeight.Bold else FontWeight.Normal,
                color = if (savedFailed) cs.error else cs.primary,
                modifier = Modifier.padding(top = 6.dp),
            )
        }
        Button(
            onClick = {
                SysPrefs.setPersonalTag(ctx, personalTag.trim())
                HeaderHelp.apply(ctx)
                ProtoPrefs.setProvider(ctx, chatProto); ProtoPrefs.apply(ctx)
                ImagePrefs.setBase(ctx, imgBase.trim()); ImagePrefs.setModel(ctx, imgModel.trim())
                ImagePrefs.setEditPath(ctx, imgEditPath.trim()); ImagePrefs.setApiKey(ctx, imgKey.trim())
                EmbedPrefs.setBase(ctx, embBase.trim()); EmbedPrefs.setModel(ctx, embModel.trim()); EmbedPrefs.setKey(ctx, embKey.trim())
                EmbedPrefs.apply(ctx)
                BackupPrefs.setBase(ctx, bkBase.trim()); BackupPrefs.setModel(ctx, bkModel.trim())
                BackupPrefs.setKey(ctx, bkKey.trim()); BackupPrefs.setProvider(ctx, bkProvider)
                BackupPrefs.apply(ctx)
                ProxyPrefs.setUrl(ctx, proxyUrl.trim()); ProxyPrefs.apply(ctx)
                proxyNow = proxyUrl.trim().ifBlank { Loc.t("（直连）") }
                val vr = VisualCfg.initIfConfigured(ctx)
                savedFailed = vr.startsWith("ERR")
                saved = if (vr == "not-configured") sSavedImgMissing
                else if (vr.startsWith("ERR")) sSavedImgFail + vr.removePrefix("ERR:")
                else sSavedImgReady
                toast(saved)
            },
            shape = RoundedCornerShape(LocalCornerRadius.current),
            modifier = Modifier.fillMaxWidth(),
        ) { Text(l10n("保存这些设置", "Save")) }
        Spacer(Modifier.height(16.dp))
    }
}
