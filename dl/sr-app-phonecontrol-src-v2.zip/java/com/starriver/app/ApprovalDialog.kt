package com.starriver.app

import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** 全局审批弹窗：完整显示待执行动作（不截断），内容可滚动；硬阻断等待用户决定。 */
@Composable
fun ApprovalDialog() {
    val req = ApprovalGate.current.value ?: return
    AlertDialog(
        onDismissRequest = { ApprovalGate.deny(req.id) },
        title = { Text("AI 请求操作手机") },
        text = {
            androidx.compose.foundation.layout.Column {
                Text("工具：" + req.tool)
                Text("动作（完整内容，共 " + req.userTarget.length + " 字符）：")
                androidx.compose.foundation.layout.Box(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                    Text(req.userTarget)
                }
                if (req.tool == "phone_tap_text") {
                    Text("\n注意：此为按文字搜索，执行时会重新在当前界面查找并点击；若界面变化，目标可能不同。请确认确实要点击该文字。")
                }
                Text("\n批准后才会真正执行；拒绝/超时会取消。")
            }
        },
        confirmButton = { TextButton(onClick = { ApprovalGate.approve(req.id) }) { Text("批准执行") } },
        dismissButton = { TextButton(onClick = { ApprovalGate.deny(req.id) }) { Text("拒绝") } },
    )
}
