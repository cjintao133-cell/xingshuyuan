package com.starriver.app

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable

/** 全局审批弹窗：有待审批的手机写操作就在任意界面弹起，硬阻断等待用户决定。 */
@Composable
fun ApprovalDialog() {
    val req = ApprovalGate.current.value ?: return
    AlertDialog(
        onDismissRequest = { ApprovalGate.deny(req.id) },
        title = { Text("AI 请求操作手机") },
        text = { Text("工具：" + req.tool + "\n动作：" + req.userTarget + "\n\n批准后才会真正执行；拒绝/超时会取消。") },
        confirmButton = { TextButton(onClick = { ApprovalGate.approve(req.id) }) { Text("批准执行") } },
        dismissButton = { TextButton(onClick = { ApprovalGate.deny(req.id) }) { Text("拒绝") } },
    )
}
