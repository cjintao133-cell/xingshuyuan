package com.starriver.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** 手机控制授权页：无障碍(读屏/点击) + 屏幕捕获(让 AI 看到画面)，并列出已暴露的 MCP 工具。 */
@Composable
fun PhoneControlScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(1200); tick++ } }
    val accReady = remember(tick) { PhoneAccessibilityService.isReady() }
    val capReady = remember(tick) { ScreenCaptureService.isReady() }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val d = res.data
        if (res.resultCode == Activity.RESULT_OK && d != null) ScreenCaptureService.start(ctx, res.resultCode, d)
        tick++
    }

    Column(Modifier.fillMaxSize().background(cs.background).verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("手机控制", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = cs.onBackground)
        Text("让 AI 读取屏幕、操作手机。两步都开启后，AI 才能“看到”并“点击”。", fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp, bottom = 10.dp))

        // 无障碍
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = cs.surfaceVariant)) {
            Column(Modifier.padding(14.dp)) {
                Text("① 无障碍服务（读屏 / 点击 / 输入 / 滑动）", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = cs.onSurface)
                Spacer(Modifier.height(4.dp))
                Text(if (accReady) "状态：已开启 ✓" else "状态：未开启", fontSize = 12.sp, color = if (accReady) cs.primary else cs.error)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { try { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {} }) {
                    Text(if (accReady) "已开启（可再检查）" else "去开启无障碍")
                }
                Text("在列表里找到「星枢元 · 手机控制」并打开。vivo/OriginOS 可能藏在“无障碍→已下载/已安装的服务”。", fontSize = 11.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
            }
        }
        Spacer(Modifier.height(10.dp))

        // 屏幕捕获
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = cs.surfaceVariant)) {
            Column(Modifier.padding(14.dp)) {
                Text("② 屏幕捕获（让 AI 看到画面）", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = cs.onSurface)
                Spacer(Modifier.height(4.dp))
                Text(if (capReady) "状态：运行中 ✓" else "状态：未授权", fontSize = 12.sp, color = if (capReady) cs.primary else cs.error)
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    try {
                        val mpm = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        launcher.launch(mpm.createScreenCaptureIntent())
                    } catch (e: Exception) {}
                }) { Text(if (capReady) "重新授权" else "授权屏幕捕获") }
                Text("每次重启手机后需重新点一次授权。不关机则一直有效。", fontSize = 11.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
            }
        }
        Spacer(Modifier.height(14.dp))

        // 已注册工具
        Text("已暴露的 MCP 工具（" + LocalMcpServer.toolCount() + "）", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = cs.onSurface)
        Spacer(Modifier.height(6.dp))
        val names = LocalMcpServer.toolNames()
        Text(if (names.isEmpty()) "（无）" else names.joinToString("\n") { "· $it" }, fontSize = 12.sp, color = cs.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = onBack) { Text("返回") }
        Spacer(Modifier.height(24.dp))
    }
}
